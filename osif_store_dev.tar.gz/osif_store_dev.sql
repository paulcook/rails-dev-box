--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: licenses; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE licenses (
    id integer NOT NULL,
    name character varying(255),
    license_version character varying(255),
    license_file_file_name character varying(255),
    license_file_content_type character varying(255),
    license_file_file_size integer,
    license_file_updated_at timestamp without time zone,
    license_text text
);


ALTER TABLE public.licenses OWNER TO vagrant;

--
-- Name: licenses_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE licenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.licenses_id_seq OWNER TO vagrant;

--
-- Name: licenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE licenses_id_seq OWNED BY licenses.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO vagrant;

--
-- Name: spree_addresses; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_addresses (
    id integer NOT NULL,
    firstname character varying(255),
    lastname character varying(255),
    address1 character varying(255),
    address2 character varying(255),
    city character varying(255),
    zipcode character varying(255),
    phone character varying(255),
    state_name character varying(255),
    alternative_phone character varying(255),
    company character varying(255),
    state_id integer,
    country_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_addresses OWNER TO vagrant;

--
-- Name: spree_addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_addresses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_addresses_id_seq OWNER TO vagrant;

--
-- Name: spree_addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_addresses_id_seq OWNED BY spree_addresses.id;


--
-- Name: spree_adjustments; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_adjustments (
    id integer NOT NULL,
    source_id integer,
    source_type character varying(255),
    adjustable_id integer,
    adjustable_type character varying(255),
    amount numeric(10,2),
    label character varying(255),
    mandatory boolean,
    eligible boolean DEFAULT true,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    state character varying(255),
    order_id integer,
    included boolean DEFAULT false
);


ALTER TABLE public.spree_adjustments OWNER TO vagrant;

--
-- Name: spree_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_adjustments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_adjustments_id_seq OWNER TO vagrant;

--
-- Name: spree_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_adjustments_id_seq OWNED BY spree_adjustments.id;


--
-- Name: spree_assets; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_assets (
    id integer NOT NULL,
    viewable_id integer,
    viewable_type character varying(255),
    attachment_width integer,
    attachment_height integer,
    attachment_file_size integer,
    "position" integer,
    attachment_content_type character varying(255),
    attachment_file_name character varying(255),
    type character varying(75),
    attachment_updated_at timestamp without time zone,
    alt text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_assets OWNER TO vagrant;

--
-- Name: spree_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_assets_id_seq OWNER TO vagrant;

--
-- Name: spree_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_assets_id_seq OWNED BY spree_assets.id;


--
-- Name: spree_calculators; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_calculators (
    id integer NOT NULL,
    type character varying(255),
    calculable_id integer,
    calculable_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    preferences text
);


ALTER TABLE public.spree_calculators OWNER TO vagrant;

--
-- Name: spree_calculators_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_calculators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_calculators_id_seq OWNER TO vagrant;

--
-- Name: spree_calculators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_calculators_id_seq OWNED BY spree_calculators.id;


--
-- Name: spree_configurations; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_configurations (
    id integer NOT NULL,
    name character varying(255),
    type character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_configurations OWNER TO vagrant;

--
-- Name: spree_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_configurations_id_seq OWNER TO vagrant;

--
-- Name: spree_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_configurations_id_seq OWNED BY spree_configurations.id;


--
-- Name: spree_countries; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_countries (
    id integer NOT NULL,
    iso_name character varying(255),
    iso character varying(255),
    iso3 character varying(255),
    name character varying(255),
    numcode integer,
    states_required boolean DEFAULT false,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_countries OWNER TO vagrant;

--
-- Name: spree_countries_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_countries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_countries_id_seq OWNER TO vagrant;

--
-- Name: spree_countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_countries_id_seq OWNED BY spree_countries.id;


--
-- Name: spree_credit_cards; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_credit_cards (
    id integer NOT NULL,
    month character varying(255),
    year character varying(255),
    cc_type character varying(255),
    last_digits character varying(255),
    address_id integer,
    gateway_customer_profile_id character varying(255),
    gateway_payment_profile_id character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    name character varying(255),
    user_id integer,
    payment_method_id integer
);


ALTER TABLE public.spree_credit_cards OWNER TO vagrant;

--
-- Name: spree_credit_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_credit_cards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_credit_cards_id_seq OWNER TO vagrant;

--
-- Name: spree_credit_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_credit_cards_id_seq OWNED BY spree_credit_cards.id;


--
-- Name: spree_digital_links; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_digital_links (
    id integer NOT NULL,
    digital_id integer,
    line_item_id integer,
    secret character varying(255),
    access_counter integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_digital_links OWNER TO vagrant;

--
-- Name: spree_digital_links_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_digital_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_digital_links_id_seq OWNER TO vagrant;

--
-- Name: spree_digital_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_digital_links_id_seq OWNED BY spree_digital_links.id;


--
-- Name: spree_digitals; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_digitals (
    id integer NOT NULL,
    variant_id integer,
    attachment_file_name character varying(255),
    attachment_content_type character varying(255),
    attachment_file_size integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_digitals OWNER TO vagrant;

--
-- Name: spree_digitals_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_digitals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_digitals_id_seq OWNER TO vagrant;

--
-- Name: spree_digitals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_digitals_id_seq OWNED BY spree_digitals.id;


--
-- Name: spree_gateways; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_gateways (
    id integer NOT NULL,
    type character varying(255),
    name character varying(255),
    description text,
    active boolean DEFAULT true,
    environment character varying(255) DEFAULT 'development'::character varying,
    server character varying(255) DEFAULT 'test'::character varying,
    test_mode boolean DEFAULT true,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    preferences text
);


ALTER TABLE public.spree_gateways OWNER TO vagrant;

--
-- Name: spree_gateways_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_gateways_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_gateways_id_seq OWNER TO vagrant;

--
-- Name: spree_gateways_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_gateways_id_seq OWNED BY spree_gateways.id;


--
-- Name: spree_inventory_units; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_inventory_units (
    id integer NOT NULL,
    state character varying(255),
    variant_id integer,
    order_id integer,
    shipment_id integer,
    return_authorization_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    pending boolean DEFAULT true,
    line_item_id integer
);


ALTER TABLE public.spree_inventory_units OWNER TO vagrant;

--
-- Name: spree_inventory_units_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_inventory_units_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_inventory_units_id_seq OWNER TO vagrant;

--
-- Name: spree_inventory_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_inventory_units_id_seq OWNED BY spree_inventory_units.id;


--
-- Name: spree_line_items; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_line_items (
    id integer NOT NULL,
    variant_id integer,
    order_id integer,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    currency character varying(255),
    cost_price numeric(10,2),
    tax_category_id integer,
    adjustment_total numeric(10,2) DEFAULT 0.0,
    additional_tax_total numeric(10,2) DEFAULT 0.0,
    promo_total numeric(10,2) DEFAULT 0.0,
    included_tax_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    pre_tax_amount numeric(8,2) DEFAULT 0
);


ALTER TABLE public.spree_line_items OWNER TO vagrant;

--
-- Name: spree_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_line_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_line_items_id_seq OWNER TO vagrant;

--
-- Name: spree_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_line_items_id_seq OWNED BY spree_line_items.id;


--
-- Name: spree_log_entries; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_log_entries (
    id integer NOT NULL,
    source_id integer,
    source_type character varying(255),
    details text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_log_entries OWNER TO vagrant;

--
-- Name: spree_log_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_log_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_log_entries_id_seq OWNER TO vagrant;

--
-- Name: spree_log_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_log_entries_id_seq OWNED BY spree_log_entries.id;


--
-- Name: spree_option_types; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_option_types (
    id integer NOT NULL,
    name character varying(100),
    presentation character varying(100),
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_option_types OWNER TO vagrant;

--
-- Name: spree_option_types_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_option_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_option_types_id_seq OWNER TO vagrant;

--
-- Name: spree_option_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_option_types_id_seq OWNED BY spree_option_types.id;


--
-- Name: spree_option_types_prototypes; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_option_types_prototypes (
    prototype_id integer,
    option_type_id integer
);


ALTER TABLE public.spree_option_types_prototypes OWNER TO vagrant;

--
-- Name: spree_option_values; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_option_values (
    id integer NOT NULL,
    "position" integer,
    name character varying(255),
    presentation character varying(255),
    option_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_option_values OWNER TO vagrant;

--
-- Name: spree_option_values_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_option_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_option_values_id_seq OWNER TO vagrant;

--
-- Name: spree_option_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_option_values_id_seq OWNED BY spree_option_values.id;


--
-- Name: spree_option_values_variants; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_option_values_variants (
    variant_id integer,
    option_value_id integer
);


ALTER TABLE public.spree_option_values_variants OWNER TO vagrant;

--
-- Name: spree_orders; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_orders (
    id integer NOT NULL,
    number character varying(32),
    item_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    total numeric(10,2) DEFAULT 0.0 NOT NULL,
    state character varying(255),
    adjustment_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    user_id integer,
    completed_at timestamp without time zone,
    bill_address_id integer,
    ship_address_id integer,
    payment_total numeric(10,2) DEFAULT 0.0,
    shipping_method_id integer,
    shipment_state character varying(255),
    payment_state character varying(255),
    email character varying(255),
    special_instructions text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    currency character varying(255),
    last_ip_address character varying(255),
    created_by_id integer,
    shipment_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    additional_tax_total numeric(10,2) DEFAULT 0.0,
    promo_total numeric(10,2) DEFAULT 0.0,
    channel character varying(255) DEFAULT 'spree'::character varying,
    included_tax_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    item_count integer DEFAULT 0,
    approver_id integer,
    approved_at timestamp without time zone,
    confirmation_delivered boolean DEFAULT false,
    considered_risky boolean DEFAULT false,
    guest_token character varying(255),
    state_lock_version integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.spree_orders OWNER TO vagrant;

--
-- Name: spree_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_orders_id_seq OWNER TO vagrant;

--
-- Name: spree_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_orders_id_seq OWNED BY spree_orders.id;


--
-- Name: spree_orders_promotions; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_orders_promotions (
    order_id integer,
    promotion_id integer
);


ALTER TABLE public.spree_orders_promotions OWNER TO vagrant;

--
-- Name: spree_payment_capture_events; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_payment_capture_events (
    id integer NOT NULL,
    amount numeric(10,2) DEFAULT 0.0,
    payment_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_payment_capture_events OWNER TO vagrant;

--
-- Name: spree_payment_capture_events_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_payment_capture_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_payment_capture_events_id_seq OWNER TO vagrant;

--
-- Name: spree_payment_capture_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_payment_capture_events_id_seq OWNED BY spree_payment_capture_events.id;


--
-- Name: spree_payment_methods; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_payment_methods (
    id integer NOT NULL,
    type character varying(255),
    name character varying(255),
    description text,
    active boolean DEFAULT true,
    environment character varying(255) DEFAULT 'development'::character varying,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    display_on character varying(255),
    auto_capture boolean,
    preferences text
);


ALTER TABLE public.spree_payment_methods OWNER TO vagrant;

--
-- Name: spree_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_payment_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_payment_methods_id_seq OWNER TO vagrant;

--
-- Name: spree_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_payment_methods_id_seq OWNED BY spree_payment_methods.id;


--
-- Name: spree_payments; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_payments (
    id integer NOT NULL,
    amount numeric(10,2) DEFAULT 0.0 NOT NULL,
    order_id integer,
    source_id integer,
    source_type character varying(255),
    payment_method_id integer,
    state character varying(255),
    response_code character varying(255),
    avs_response character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    identifier character varying(255),
    cvv_response_code character varying(255),
    cvv_response_message character varying(255)
);


ALTER TABLE public.spree_payments OWNER TO vagrant;

--
-- Name: spree_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_payments_id_seq OWNER TO vagrant;

--
-- Name: spree_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_payments_id_seq OWNED BY spree_payments.id;


--
-- Name: spree_preferences; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_preferences (
    id integer NOT NULL,
    value text,
    key character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_preferences OWNER TO vagrant;

--
-- Name: spree_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_preferences_id_seq OWNER TO vagrant;

--
-- Name: spree_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_preferences_id_seq OWNED BY spree_preferences.id;


--
-- Name: spree_prices; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_prices (
    id integer NOT NULL,
    variant_id integer NOT NULL,
    amount numeric(10,2),
    currency character varying(255),
    deleted_at timestamp without time zone
);


ALTER TABLE public.spree_prices OWNER TO vagrant;

--
-- Name: spree_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_prices_id_seq OWNER TO vagrant;

--
-- Name: spree_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_prices_id_seq OWNED BY spree_prices.id;


--
-- Name: spree_product_option_types; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_product_option_types (
    id integer NOT NULL,
    "position" integer,
    product_id integer,
    option_type_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_product_option_types OWNER TO vagrant;

--
-- Name: spree_product_option_types_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_product_option_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_product_option_types_id_seq OWNER TO vagrant;

--
-- Name: spree_product_option_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_product_option_types_id_seq OWNED BY spree_product_option_types.id;


--
-- Name: spree_product_properties; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_product_properties (
    id integer NOT NULL,
    value character varying(255),
    product_id integer,
    property_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" integer DEFAULT 0
);


ALTER TABLE public.spree_product_properties OWNER TO vagrant;

--
-- Name: spree_product_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_product_properties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_product_properties_id_seq OWNER TO vagrant;

--
-- Name: spree_product_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_product_properties_id_seq OWNED BY spree_product_properties.id;


--
-- Name: spree_products; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_products (
    id integer NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    description text,
    available_on timestamp without time zone,
    deleted_at timestamp without time zone,
    slug character varying(255),
    meta_description text,
    meta_keywords character varying(255),
    tax_category_id integer,
    shipping_category_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    license_id integer DEFAULT 1 NOT NULL,
    marketing_page boolean DEFAULT false NOT NULL,
    external_title character varying(255) DEFAULT ''::character varying NOT NULL,
    external_url character varying(255) DEFAULT ''::character varying NOT NULL,
    apple_itunes_url character varying(255) DEFAULT ''::character varying NOT NULL,
    google_play_url character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.spree_products OWNER TO vagrant;

--
-- Name: spree_products_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_products_id_seq OWNER TO vagrant;

--
-- Name: spree_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_products_id_seq OWNED BY spree_products.id;


--
-- Name: spree_products_promotion_rules; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_products_promotion_rules (
    product_id integer,
    promotion_rule_id integer
);


ALTER TABLE public.spree_products_promotion_rules OWNER TO vagrant;

--
-- Name: spree_products_taxons; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_products_taxons (
    product_id integer,
    taxon_id integer,
    id integer NOT NULL,
    "position" integer
);


ALTER TABLE public.spree_products_taxons OWNER TO vagrant;

--
-- Name: spree_products_taxons_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_products_taxons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_products_taxons_id_seq OWNER TO vagrant;

--
-- Name: spree_products_taxons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_products_taxons_id_seq OWNED BY spree_products_taxons.id;


--
-- Name: spree_promotion_action_line_items; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_promotion_action_line_items (
    id integer NOT NULL,
    promotion_action_id integer,
    variant_id integer,
    quantity integer DEFAULT 1
);


ALTER TABLE public.spree_promotion_action_line_items OWNER TO vagrant;

--
-- Name: spree_promotion_action_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_promotion_action_line_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_promotion_action_line_items_id_seq OWNER TO vagrant;

--
-- Name: spree_promotion_action_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_promotion_action_line_items_id_seq OWNED BY spree_promotion_action_line_items.id;


--
-- Name: spree_promotion_actions; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_promotion_actions (
    id integer NOT NULL,
    promotion_id integer,
    "position" integer,
    type character varying(255),
    deleted_at timestamp without time zone
);


ALTER TABLE public.spree_promotion_actions OWNER TO vagrant;

--
-- Name: spree_promotion_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_promotion_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_promotion_actions_id_seq OWNER TO vagrant;

--
-- Name: spree_promotion_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_promotion_actions_id_seq OWNED BY spree_promotion_actions.id;


--
-- Name: spree_promotion_rules; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_promotion_rules (
    id integer NOT NULL,
    promotion_id integer,
    user_id integer,
    product_group_id integer,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    code character varying(255),
    preferences text
);


ALTER TABLE public.spree_promotion_rules OWNER TO vagrant;

--
-- Name: spree_promotion_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_promotion_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_promotion_rules_id_seq OWNER TO vagrant;

--
-- Name: spree_promotion_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_promotion_rules_id_seq OWNED BY spree_promotion_rules.id;


--
-- Name: spree_promotion_rules_users; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_promotion_rules_users (
    user_id integer,
    promotion_rule_id integer
);


ALTER TABLE public.spree_promotion_rules_users OWNER TO vagrant;

--
-- Name: spree_promotions; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_promotions (
    id integer NOT NULL,
    description character varying(255),
    expires_at timestamp without time zone,
    starts_at timestamp without time zone,
    name character varying(255),
    type character varying(255),
    usage_limit integer,
    match_policy character varying(255) DEFAULT 'all'::character varying,
    code character varying(255),
    advertise boolean DEFAULT false,
    path character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_promotions OWNER TO vagrant;

--
-- Name: spree_promotions_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_promotions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_promotions_id_seq OWNER TO vagrant;

--
-- Name: spree_promotions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_promotions_id_seq OWNED BY spree_promotions.id;


--
-- Name: spree_properties; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_properties (
    id integer NOT NULL,
    name character varying(255),
    presentation character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_properties OWNER TO vagrant;

--
-- Name: spree_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_properties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_properties_id_seq OWNER TO vagrant;

--
-- Name: spree_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_properties_id_seq OWNED BY spree_properties.id;


--
-- Name: spree_properties_prototypes; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_properties_prototypes (
    prototype_id integer,
    property_id integer
);


ALTER TABLE public.spree_properties_prototypes OWNER TO vagrant;

--
-- Name: spree_prototypes; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_prototypes (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_prototypes OWNER TO vagrant;

--
-- Name: spree_prototypes_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_prototypes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_prototypes_id_seq OWNER TO vagrant;

--
-- Name: spree_prototypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_prototypes_id_seq OWNED BY spree_prototypes.id;


--
-- Name: spree_return_authorizations; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_return_authorizations (
    id integer NOT NULL,
    number character varying(255),
    state character varying(255),
    amount numeric(10,2) DEFAULT 0.0 NOT NULL,
    order_id integer,
    reason text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    stock_location_id integer
);


ALTER TABLE public.spree_return_authorizations OWNER TO vagrant;

--
-- Name: spree_return_authorizations_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_return_authorizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_return_authorizations_id_seq OWNER TO vagrant;

--
-- Name: spree_return_authorizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_return_authorizations_id_seq OWNED BY spree_return_authorizations.id;


--
-- Name: spree_roles; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_roles (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public.spree_roles OWNER TO vagrant;

--
-- Name: spree_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_roles_id_seq OWNER TO vagrant;

--
-- Name: spree_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_roles_id_seq OWNED BY spree_roles.id;


--
-- Name: spree_roles_users; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_roles_users (
    role_id integer,
    user_id integer
);


ALTER TABLE public.spree_roles_users OWNER TO vagrant;

--
-- Name: spree_shipments; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipments (
    id integer NOT NULL,
    tracking character varying(255),
    number character varying(255),
    cost numeric(10,2) DEFAULT 0.0,
    shipped_at timestamp without time zone,
    order_id integer,
    address_id integer,
    state character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    stock_location_id integer,
    adjustment_total numeric(10,2) DEFAULT 0.0,
    additional_tax_total numeric(10,2) DEFAULT 0.0,
    promo_total numeric(10,2) DEFAULT 0.0,
    included_tax_total numeric(10,2) DEFAULT 0.0 NOT NULL,
    pre_tax_amount numeric(8,2) DEFAULT 0
);


ALTER TABLE public.spree_shipments OWNER TO vagrant;

--
-- Name: spree_shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_shipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_shipments_id_seq OWNER TO vagrant;

--
-- Name: spree_shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_shipments_id_seq OWNED BY spree_shipments.id;


--
-- Name: spree_shipping_categories; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipping_categories (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_shipping_categories OWNER TO vagrant;

--
-- Name: spree_shipping_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_shipping_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_shipping_categories_id_seq OWNER TO vagrant;

--
-- Name: spree_shipping_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_shipping_categories_id_seq OWNED BY spree_shipping_categories.id;


--
-- Name: spree_shipping_method_categories; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipping_method_categories (
    id integer NOT NULL,
    shipping_method_id integer NOT NULL,
    shipping_category_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_shipping_method_categories OWNER TO vagrant;

--
-- Name: spree_shipping_method_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_shipping_method_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_shipping_method_categories_id_seq OWNER TO vagrant;

--
-- Name: spree_shipping_method_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_shipping_method_categories_id_seq OWNED BY spree_shipping_method_categories.id;


--
-- Name: spree_shipping_methods; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipping_methods (
    id integer NOT NULL,
    name character varying(255),
    display_on character varying(255),
    deleted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tracking_url character varying(255),
    admin_name character varying(255),
    tax_category_id integer
);


ALTER TABLE public.spree_shipping_methods OWNER TO vagrant;

--
-- Name: spree_shipping_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_shipping_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_shipping_methods_id_seq OWNER TO vagrant;

--
-- Name: spree_shipping_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_shipping_methods_id_seq OWNED BY spree_shipping_methods.id;


--
-- Name: spree_shipping_methods_zones; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipping_methods_zones (
    shipping_method_id integer,
    zone_id integer
);


ALTER TABLE public.spree_shipping_methods_zones OWNER TO vagrant;

--
-- Name: spree_shipping_rates; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_shipping_rates (
    id integer NOT NULL,
    shipment_id integer,
    shipping_method_id integer,
    selected boolean DEFAULT false,
    cost numeric(8,2) DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tax_rate_id integer
);


ALTER TABLE public.spree_shipping_rates OWNER TO vagrant;

--
-- Name: spree_shipping_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_shipping_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_shipping_rates_id_seq OWNER TO vagrant;

--
-- Name: spree_shipping_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_shipping_rates_id_seq OWNED BY spree_shipping_rates.id;


--
-- Name: spree_skrill_transactions; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_skrill_transactions (
    id integer NOT NULL,
    email character varying(255),
    amount double precision,
    currency character varying(255),
    transaction_id integer,
    customer_id integer,
    payment_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_skrill_transactions OWNER TO vagrant;

--
-- Name: spree_skrill_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_skrill_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_skrill_transactions_id_seq OWNER TO vagrant;

--
-- Name: spree_skrill_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_skrill_transactions_id_seq OWNED BY spree_skrill_transactions.id;


--
-- Name: spree_state_changes; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_state_changes (
    id integer NOT NULL,
    name character varying(255),
    previous_state character varying(255),
    stateful_id integer,
    user_id integer,
    stateful_type character varying(255),
    next_state character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_state_changes OWNER TO vagrant;

--
-- Name: spree_state_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_state_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_state_changes_id_seq OWNER TO vagrant;

--
-- Name: spree_state_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_state_changes_id_seq OWNED BY spree_state_changes.id;


--
-- Name: spree_states; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_states (
    id integer NOT NULL,
    name character varying(255),
    abbr character varying(255),
    country_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_states OWNER TO vagrant;

--
-- Name: spree_states_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_states_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_states_id_seq OWNER TO vagrant;

--
-- Name: spree_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_states_id_seq OWNED BY spree_states.id;


--
-- Name: spree_stock_items; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_stock_items (
    id integer NOT NULL,
    stock_location_id integer,
    variant_id integer,
    count_on_hand integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    backorderable boolean DEFAULT false,
    deleted_at timestamp without time zone
);


ALTER TABLE public.spree_stock_items OWNER TO vagrant;

--
-- Name: spree_stock_items_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_stock_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_stock_items_id_seq OWNER TO vagrant;

--
-- Name: spree_stock_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_stock_items_id_seq OWNED BY spree_stock_items.id;


--
-- Name: spree_stock_locations; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_stock_locations (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    address1 character varying(255),
    address2 character varying(255),
    city character varying(255),
    state_id integer,
    state_name character varying(255),
    country_id integer,
    zipcode character varying(255),
    phone character varying(255),
    active boolean DEFAULT true,
    backorderable_default boolean DEFAULT false,
    propagate_all_variants boolean DEFAULT true,
    admin_name character varying(255)
);


ALTER TABLE public.spree_stock_locations OWNER TO vagrant;

--
-- Name: spree_stock_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_stock_locations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_stock_locations_id_seq OWNER TO vagrant;

--
-- Name: spree_stock_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_stock_locations_id_seq OWNED BY spree_stock_locations.id;


--
-- Name: spree_stock_movements; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_stock_movements (
    id integer NOT NULL,
    stock_item_id integer,
    quantity integer DEFAULT 0,
    action character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    originator_id integer,
    originator_type character varying(255)
);


ALTER TABLE public.spree_stock_movements OWNER TO vagrant;

--
-- Name: spree_stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_stock_movements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_stock_movements_id_seq OWNER TO vagrant;

--
-- Name: spree_stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_stock_movements_id_seq OWNED BY spree_stock_movements.id;


--
-- Name: spree_stock_transfers; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_stock_transfers (
    id integer NOT NULL,
    type character varying(255),
    reference character varying(255),
    source_location_id integer,
    destination_location_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    number character varying(255)
);


ALTER TABLE public.spree_stock_transfers OWNER TO vagrant;

--
-- Name: spree_stock_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_stock_transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_stock_transfers_id_seq OWNER TO vagrant;

--
-- Name: spree_stock_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_stock_transfers_id_seq OWNED BY spree_stock_transfers.id;


--
-- Name: spree_stores; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_stores (
    id integer NOT NULL,
    name character varying(255),
    url character varying(255),
    meta_description text,
    meta_keywords text,
    seo_title character varying(255),
    mail_from_address character varying(255),
    default_currency character varying(255),
    code character varying(255),
    "default" boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_stores OWNER TO vagrant;

--
-- Name: spree_stores_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_stores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_stores_id_seq OWNER TO vagrant;

--
-- Name: spree_stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_stores_id_seq OWNED BY spree_stores.id;


--
-- Name: spree_tax_categories; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_tax_categories (
    id integer NOT NULL,
    name character varying(255),
    description character varying(255),
    is_default boolean DEFAULT false,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_tax_categories OWNER TO vagrant;

--
-- Name: spree_tax_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_tax_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_tax_categories_id_seq OWNER TO vagrant;

--
-- Name: spree_tax_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_tax_categories_id_seq OWNED BY spree_tax_categories.id;


--
-- Name: spree_tax_rates; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_tax_rates (
    id integer NOT NULL,
    amount numeric(8,5),
    zone_id integer,
    tax_category_id integer,
    included_in_price boolean DEFAULT false,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    name character varying(255),
    show_rate_in_label boolean DEFAULT true,
    deleted_at timestamp without time zone
);


ALTER TABLE public.spree_tax_rates OWNER TO vagrant;

--
-- Name: spree_tax_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_tax_rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_tax_rates_id_seq OWNER TO vagrant;

--
-- Name: spree_tax_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_tax_rates_id_seq OWNED BY spree_tax_rates.id;


--
-- Name: spree_taxonomies; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_taxonomies (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" integer DEFAULT 0
);


ALTER TABLE public.spree_taxonomies OWNER TO vagrant;

--
-- Name: spree_taxonomies_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_taxonomies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_taxonomies_id_seq OWNER TO vagrant;

--
-- Name: spree_taxonomies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_taxonomies_id_seq OWNED BY spree_taxonomies.id;


--
-- Name: spree_taxons; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_taxons (
    id integer NOT NULL,
    parent_id integer,
    "position" integer DEFAULT 0,
    name character varying(255) NOT NULL,
    permalink character varying(255),
    taxonomy_id integer,
    lft integer,
    rgt integer,
    icon_file_name character varying(255),
    icon_content_type character varying(255),
    icon_file_size integer,
    icon_updated_at timestamp without time zone,
    description text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    meta_title character varying(255),
    meta_description character varying(255),
    meta_keywords character varying(255),
    depth integer
);


ALTER TABLE public.spree_taxons OWNER TO vagrant;

--
-- Name: spree_taxons_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_taxons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_taxons_id_seq OWNER TO vagrant;

--
-- Name: spree_taxons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_taxons_id_seq OWNED BY spree_taxons.id;


--
-- Name: spree_tokenized_permissions; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_tokenized_permissions (
    id integer NOT NULL,
    permissable_id integer,
    permissable_type character varying(255),
    token character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_tokenized_permissions OWNER TO vagrant;

--
-- Name: spree_tokenized_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_tokenized_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_tokenized_permissions_id_seq OWNER TO vagrant;

--
-- Name: spree_tokenized_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_tokenized_permissions_id_seq OWNED BY spree_tokenized_permissions.id;


--
-- Name: spree_trackers; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_trackers (
    id integer NOT NULL,
    environment character varying(255),
    analytics_id character varying(255),
    active boolean DEFAULT true,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_trackers OWNER TO vagrant;

--
-- Name: spree_trackers_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_trackers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_trackers_id_seq OWNER TO vagrant;

--
-- Name: spree_trackers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_trackers_id_seq OWNED BY spree_trackers.id;


--
-- Name: spree_users; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_users (
    id integer NOT NULL,
    encrypted_password character varying(128),
    password_salt character varying(128),
    email character varying(255),
    remember_token character varying(255),
    persistence_token character varying(255),
    reset_password_token character varying(255),
    perishable_token character varying(255),
    sign_in_count integer DEFAULT 0 NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    last_request_at timestamp without time zone,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    login character varying(255),
    ship_address_id integer,
    bill_address_id integer,
    authentication_token character varying(255),
    unlock_token character varying(255),
    locked_at timestamp without time zone,
    reset_password_sent_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    spree_api_key character varying(48),
    remember_created_at timestamp without time zone
);


ALTER TABLE public.spree_users OWNER TO vagrant;

--
-- Name: spree_users_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_users_id_seq OWNER TO vagrant;

--
-- Name: spree_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_users_id_seq OWNED BY spree_users.id;


--
-- Name: spree_variants; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_variants (
    id integer NOT NULL,
    sku character varying(255) DEFAULT ''::character varying NOT NULL,
    weight numeric(8,2) DEFAULT 0.0,
    height numeric(8,2),
    width numeric(8,2),
    depth numeric(8,2),
    deleted_at timestamp without time zone,
    is_master boolean DEFAULT false,
    product_id integer,
    cost_price numeric(10,2),
    "position" integer,
    cost_currency character varying(255),
    track_inventory boolean DEFAULT true,
    tax_category_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_variants OWNER TO vagrant;

--
-- Name: spree_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_variants_id_seq OWNER TO vagrant;

--
-- Name: spree_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_variants_id_seq OWNED BY spree_variants.id;


--
-- Name: spree_zone_members; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_zone_members (
    id integer NOT NULL,
    zoneable_id integer,
    zoneable_type character varying(255),
    zone_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_zone_members OWNER TO vagrant;

--
-- Name: spree_zone_members_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_zone_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_zone_members_id_seq OWNER TO vagrant;

--
-- Name: spree_zone_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_zone_members_id_seq OWNED BY spree_zone_members.id;


--
-- Name: spree_zones; Type: TABLE; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE TABLE spree_zones (
    id integer NOT NULL,
    name character varying(255),
    description character varying(255),
    default_tax boolean DEFAULT false,
    zone_members_count integer DEFAULT 0,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.spree_zones OWNER TO vagrant;

--
-- Name: spree_zones_id_seq; Type: SEQUENCE; Schema: public; Owner: vagrant
--

CREATE SEQUENCE spree_zones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spree_zones_id_seq OWNER TO vagrant;

--
-- Name: spree_zones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vagrant
--

ALTER SEQUENCE spree_zones_id_seq OWNED BY spree_zones.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY licenses ALTER COLUMN id SET DEFAULT nextval('licenses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_addresses ALTER COLUMN id SET DEFAULT nextval('spree_addresses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_adjustments ALTER COLUMN id SET DEFAULT nextval('spree_adjustments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_assets ALTER COLUMN id SET DEFAULT nextval('spree_assets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_calculators ALTER COLUMN id SET DEFAULT nextval('spree_calculators_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_configurations ALTER COLUMN id SET DEFAULT nextval('spree_configurations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_countries ALTER COLUMN id SET DEFAULT nextval('spree_countries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_credit_cards ALTER COLUMN id SET DEFAULT nextval('spree_credit_cards_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_digital_links ALTER COLUMN id SET DEFAULT nextval('spree_digital_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_digitals ALTER COLUMN id SET DEFAULT nextval('spree_digitals_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_gateways ALTER COLUMN id SET DEFAULT nextval('spree_gateways_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_inventory_units ALTER COLUMN id SET DEFAULT nextval('spree_inventory_units_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_line_items ALTER COLUMN id SET DEFAULT nextval('spree_line_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_log_entries ALTER COLUMN id SET DEFAULT nextval('spree_log_entries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_option_types ALTER COLUMN id SET DEFAULT nextval('spree_option_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_option_values ALTER COLUMN id SET DEFAULT nextval('spree_option_values_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_orders ALTER COLUMN id SET DEFAULT nextval('spree_orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_payment_capture_events ALTER COLUMN id SET DEFAULT nextval('spree_payment_capture_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_payment_methods ALTER COLUMN id SET DEFAULT nextval('spree_payment_methods_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_payments ALTER COLUMN id SET DEFAULT nextval('spree_payments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_preferences ALTER COLUMN id SET DEFAULT nextval('spree_preferences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_prices ALTER COLUMN id SET DEFAULT nextval('spree_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_product_option_types ALTER COLUMN id SET DEFAULT nextval('spree_product_option_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_product_properties ALTER COLUMN id SET DEFAULT nextval('spree_product_properties_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_products ALTER COLUMN id SET DEFAULT nextval('spree_products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_products_taxons ALTER COLUMN id SET DEFAULT nextval('spree_products_taxons_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_promotion_action_line_items ALTER COLUMN id SET DEFAULT nextval('spree_promotion_action_line_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_promotion_actions ALTER COLUMN id SET DEFAULT nextval('spree_promotion_actions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_promotion_rules ALTER COLUMN id SET DEFAULT nextval('spree_promotion_rules_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_promotions ALTER COLUMN id SET DEFAULT nextval('spree_promotions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_properties ALTER COLUMN id SET DEFAULT nextval('spree_properties_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_prototypes ALTER COLUMN id SET DEFAULT nextval('spree_prototypes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_return_authorizations ALTER COLUMN id SET DEFAULT nextval('spree_return_authorizations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_roles ALTER COLUMN id SET DEFAULT nextval('spree_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_shipments ALTER COLUMN id SET DEFAULT nextval('spree_shipments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_shipping_categories ALTER COLUMN id SET DEFAULT nextval('spree_shipping_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_shipping_method_categories ALTER COLUMN id SET DEFAULT nextval('spree_shipping_method_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_shipping_methods ALTER COLUMN id SET DEFAULT nextval('spree_shipping_methods_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_shipping_rates ALTER COLUMN id SET DEFAULT nextval('spree_shipping_rates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_skrill_transactions ALTER COLUMN id SET DEFAULT nextval('spree_skrill_transactions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_state_changes ALTER COLUMN id SET DEFAULT nextval('spree_state_changes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_states ALTER COLUMN id SET DEFAULT nextval('spree_states_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_stock_items ALTER COLUMN id SET DEFAULT nextval('spree_stock_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_stock_locations ALTER COLUMN id SET DEFAULT nextval('spree_stock_locations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_stock_movements ALTER COLUMN id SET DEFAULT nextval('spree_stock_movements_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_stock_transfers ALTER COLUMN id SET DEFAULT nextval('spree_stock_transfers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_stores ALTER COLUMN id SET DEFAULT nextval('spree_stores_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_tax_categories ALTER COLUMN id SET DEFAULT nextval('spree_tax_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_tax_rates ALTER COLUMN id SET DEFAULT nextval('spree_tax_rates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_taxonomies ALTER COLUMN id SET DEFAULT nextval('spree_taxonomies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_taxons ALTER COLUMN id SET DEFAULT nextval('spree_taxons_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_tokenized_permissions ALTER COLUMN id SET DEFAULT nextval('spree_tokenized_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_trackers ALTER COLUMN id SET DEFAULT nextval('spree_trackers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_users ALTER COLUMN id SET DEFAULT nextval('spree_users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_variants ALTER COLUMN id SET DEFAULT nextval('spree_variants_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_zone_members ALTER COLUMN id SET DEFAULT nextval('spree_zone_members_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: vagrant
--

ALTER TABLE ONLY spree_zones ALTER COLUMN id SET DEFAULT nextval('spree_zones_id_seq'::regclass);


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY licenses (id, name, license_version, license_file_file_name, license_file_content_type, license_file_file_size, license_file_updated_at, license_text) FROM stdin;
1	Click Wrap 1	\N	Clickwrap_software_licence_agreement__Template1.pdf	application/pdf	115011	2014-11-13 17:51:02.4358	Click-wrap Software Licence Agreement\r\nCAREFULLY READ THE FOLLOWING LICENCE AGREEMENT CAREFULLY! IT CONTAINS VERY IMPORTANT INFORMATION ABOUT YOUR RIGHTS AND OBLIGATIONS, AS WELL AS LIMITATIONS AND EXCLUSIONS THAT MAY APPLY TO YOU. THIS DOCUMENT CONTAINS A DISPUTE RESOLUTION CLAUSE. BY CLICKING ON THE “ACCEPT” BUTTON, YOU ARE CONSENTING TO BE BOUND BY AND ARE BECOMING A PARTY TO THIS AGREEMENT. IF YOU DO NOT AGREE TO ALL OF THE TERMS OF THIS AGREEMENT, CLICK THE “DO NOT ACCEPT” BUTTON OR LEAVE THE WEBSITE.\r\nPlease contact us at [info@Licensor.com] for any queries.\r\n“You” or “Your” means the person or company who is being licensed to use the Licensor software in association with the Usage Agreement (“Usage Agreement”). “We”, “Our” and “Us” means Licensor Canada Inc.\r\nNOW, THEREFORE, THIS AGREEMENT WITNESSETH that, in consideration of the mutual covenants contained herein, the Parties hereto agree as follows:\r\n1. DEFINITIONS\r\n1.1. Definitions. Capitalized terms in this Agreement will have the following meanings:\r\n“Agreement” means this Software Licence Agreement between Us and You;\r\n“Licensed Software” means certain commercial software products being provided to You under this Agreement, including executable program modules thereof, as well as related documentation and computer readable media;\r\n“Sublicensed Software” means certain third party owned software components being provided under this Agreement, that are required to properly enable or operate the Licensed Software;\r\nOther capitalized terms have the meanings defined in the Usage Agreement.\r\n2. SOFTWARE LICENCE, RIGHTS & RESTRICTIONS\r\n2.1 Software Licence and Rights. In consideration of the mutual covenants, and subject to the provisions contained in this Agreement, We hereby grant to You a revocable, non-exclusive licence to use the Licensed Software solely in order to utilize the Products and Services as provided under the Usage Agreement.\r\n2.2 Restrictions. Without limiting the generality of the foregoing, You will use the Licensed Software only for purposes set forth herein, and, further, You expressly agree that You DO NOT have rights to:\r\n(a)\town title, or transfer title to the Licensed Software to another party;\r\n(b)\tdistribute, or sublicense or otherwise provide copies or any rights in relation to the Licensed Software to any third party;\r\n(c)\tpledge, hypothecate, alienate or otherwise encumber the Licensed Software to any third party;\r\n(d)\tuse the Licensed Software to rent, lease or otherwise provide location-enabled telecommunication or information services to Your customers, including, without limitation, data processing, hosting, outsourcing, service bureau or online application services (ASP) offerings; or\r\n(e)\tmodify, enhance, reverse-engineer, decompile, disassemble or create substantially derived forms of the Licensed Software.\r\n2.3 Enforcement of Restrictions. We will have the right to inspect and enforce the restrictions and covenants contained in this Agreement at Your sole expense, and You hereby agree to promptly notify Us of any known violations of such restrictions.\r\n2.4 Our Obligations. Upon execution of this Agreement, We will:\r\n(a)\tpermit You to download a copy of the most current version of the Licensed Software for Your use under this Agreement; and\r\n(b)\tprovide You with ongoing updates to the Licensed Software as We consider needed. In each such case, We will automatically provide and install the necessary updates and will notify You when the update has been installed.\r\n3. COPYRIGHT AND MARKS\r\n3.1 Copyright. The Licensed Software, including any documentation, media, packaging and illustrations, is copyrighted and constitutes Our valuable property. You agree that all physical manifestations of the Licensed Software will display Our copyright notice in a conspicuous manner. The Licensed Software is protected under Canadian copyright laws \r\nand international treaty provisions. You Will have a right to copy the materials, provided copyright notices and acknowledgement of trade-marks are included, pursuant to the covenants herein. You will include the following notice on any printed, electronic, online or packaged version of the Licensed Software, in any form whatsoever:\r\n\t“Copyright © [date] Licensor [formal name of owner]\r\n\tAll rights reserved.”\r\n3.2 Trade-marks. Certain logos, product names and trade-marks owned by Us may be contained within the printed materials and electronic manifestations of the Licensed Software. You will have no right to use such marks in its end-user applications except as set out in the User Agreement.\r\n4. TITLE\r\n4.1 Title. You acknowledge that the Licensed Software, including any associated written materials and other documentation provided under this Agreement, belongs exclusively to Us. Unencumbered title to the Licensed Software will, at all times, remain with Us. You agree to protect the Licensed Software from unauthorized use, reproduction, distribution or publication in electronic or physical form.\r\n5. WARRANTY AND INDEMNITY\r\n5.1 Warranty. We warrant that We are the owner of the Licensed Software, and have the right and authority to grant the licence to the Licensed Software. We do not warrant, guarantee, accept any condition or make any representation that the Licensed Software will meet Your requirements or that the use of the Licensed Software will be uninterrupted or error-free. No other verbal or written information provided by Us will create a warranty or in any way increase Our liability, and You will not rely on such information.\r\n5.2 Indemnity. We warrant that the Licensed Software does not infringe on any current subsisting and enforceable Canadian patent or Canadian copyright, and We will and hereby do agree to indemnify and hold You harmless in respect of any losses, costs, damages or expenses (including reasonable attorney’s fees and court costs) arising out of any claim, demand or action alleging that the Licensed Software violates or infringes the Canadian copyright, patent or other intellectual property right of any third party, providing that You provide Us with reasonable cooperation in preparing a defence against any such claim.\r\n5.3 DISCLAIMER. THERE ARE NO WARRANTIES FOR SERVICES. WE MAKE NO EXPRESS REPRESENTATIONS OR WARRANTIES, OR ACCEPT ANY CONDITIONS EXCEPT THOSE EXPRESSLY STATED IN SECTIONS 5.1 AND 5.2 ABOVE. WE DISCLAIM ALL OTHER REPRESENTATIONS, WARRANTIES AND CONDITIONS, EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. SOME PROVINCES DO NOT PERMIT THE EXCLUSION OF CERTAIN IMPLIED WARRANTIES OR CONDITIONS. THEREFORE, THE FOREGOING DISCLAIMERS MAY NOT APPLY TO YOU.\r\n6. LIMITATION OF LIABILITY AND REMEDIES\r\n6.1 LIMITATION OF LIABILITY. IN NO EVENT WILL WE BE LIABLE FOR ANY LOSSES OR DAMAGES INCURRED BY YOU, WHETHER DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY OR CONSEQUENTIAL, INCLUDING LOST OR ANTICIPATED PROFITS, SAVINGS, INTERRUPTION TO BUSINESS, LOSS OF BUSINESS OPPORTUNITIES, LOSS OF BUSINESS INFORMATION, THE COST OF RECOVERING SUCH LOST INFORMATION, THE COST OF SUBSTITUTE INTELLECTUAL PROPERTY OR ANY OTHER PECUNIARY LOSS ARISING FROM THE USE OF, OR THE INABILITY TO USE, THE LICENSED SOFTWARE REGARDLESS OF WHETHER YOU HAVE ADVISED US OR WE HAVE ADVISED YOU OF THE POSSIBILITY OF SUCH DAMAGES. OUR AGGREGATE LIABILITY IN RESPECT OF ANY AND ALL CLAIMS WILL BE LIMITED TO ONE HUNDERD ($100.00) DOLLARS. THE FOREGOING LIMITATIONS APPLY REGARDLESS OF THE CAUSE OR CIRCUMSTANCES GIVING RISE TO SUCH LOSS, DAMAGE OR LIABILITY, EVEN IF SUCH LOSS, DAMAGE OR LIABILITY IS BASED ON NEGLIGENCE OR OTHER TORTS OR BREACH OF CONTRACT (INCLUDING FUNDAMENTAL BREACH OR BREACH OF A FUNDAMENTAL TERM).\r\nNEITHER YOU NOR WE MAY INSTITUTE ANY ACTION IN ANY FORM ARISING OUT OF THIS AGREEMENT MORE THAN ONE (1) YEAR AFTER THE CAUSE OF ACTION HAS ARISEN. SOME PROVINCES DO NOT ALLOW THE EXCLUSION OF LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES SO THE ABOVE EXCLUSIONS MAY NOT APPLY.\r\n6.2 Dispute Resolution. You acknowledge that We possess valuable confidential and proprietary information, including trade-marks and business practices, which would be damaging to Us if revealed in open court. You further acknowledge and agree that it is preferable to resolve all disputes between Us and You confidentially, individually and in an expeditious and inexpensive manner. We and You accordingly acknowledge and agree that private dispute resolution is preferable to court actions. Before commencing any arbitration in the manner set out in Section 6.3 below, We and You shall first attempt to resolve any dispute or differences between the both of us by way of good faith negotiation. The good faith negotiation shall commence by each of Us and You communicating our position regarding the complaint, claim, dispute or controversy to the other party, and how the both of us should resolve the dispute. We and You shall then make good faith efforts to negotiate a resolution of the claim, dispute or controversy. Neither We nor You shall commence any arbitral proceedings unless and until the good faith negotiation fails.\r\n6.3 ARBITRATION. ANY CLAIM, DISPUTE OR CONTROVERSY (WHETHER IN CONTRACT, TORT OR OTHERWISE, WHETHER PRE-EXISTING, PRESENT OR FUTURE, AND INCLUDING STATUTORY, COMMON LAW, INTENTIONAL TORT AND EQUITABLE CLAIMS CAPABLE IN LAW OF BEING SUBMITTED TO BINDING ARBITRATION) AGAINST US, Our agents, employees, officers, directors, successors, assigns or affiliates (collectively, for purposes of this paragraph, “Licensor Group”) arising from or relating to this Agreement, its interpretation or the breach, termination or validity thereof, the relationships between the parties, whether pre-existing, present or future (including, to the full extent permitted by applicable law, \r\nrelationships with third parties who are not signatories to this Agreement), Licensor Group’s advertising or any related purchase SHALL BE RESOLVED EXCLUSIVELY AND FINALLY BY BINDING ARBITRATION ADMINISTERED BY THE NATIONAL ARBITRATION FORUM (“NAF”) under its Code of Procedure and any specific procedures for the resolution of small claims and/or consumer disputes then in effect (available via the Internet at <http://www.arb-forum.com>, or via telephone at 1-800-474-2371). The arbitration will be limited solely to the dispute or controversy between Customer and Licensor Group. Any award of the arbitrator(s) shall be final and binding on each of us, and may be entered as a judgment in any court of competent jurisdiction. Information may be obtained, and claims may be filed with the NAF at P.O. Box 50191, Minneapolis, MN 55405, or by email at <file@arb-forum.com>, or by online filing at <http://www.arb-forum.com>.\r\n7. SUCCESSORS AND ASSIGNS\r\n7.1 Successors and Assigns. You may not assign Your rights and duties under this Agreement to any party at any time. This Agreement will enure to the benefit of and will be binding on Us and our respective successors and permitted assigns. In the event of corporate merger, amalgamation, divestiture or asset sale, We will have the right to transfer and assign Our rights and obligations hereunder to any third party (the “Assignee”), upon written notice to You, provided that We cause the Assignee to agree in writing to all the terms contained in this Agreement.\r\n8. UPGRADES\r\n8.1 Upgrades. Other than our obligation under Section 2.4(b), We shall have no other obligations to provide updates or support services to You. Obligations or expectations with regard to product upgrades, enhancements, support or remedies for errors, defects or deficiencies will be limited to those expressly set forth in a separate agreement between Us and You. In the absence of such an agreement between Us and You, We will use reasonable efforts to provide ongoing support and remedies to identified errors and defects, on a time and material basis, at Our then current commercial rates.\r\n9. CONFIDENTIALITY\r\n9.1 Confidentiality. You acknowledge that the existence of this Agreement, the terms and conditions hereof, the transactions contemplated hereby and other information, including, without limitation, customer, technical and financial information that they have received or will receive in connection with this Agreement, is considered private and confidential (the “Confidential Information”). You will use reasonable diligence and in no event less than the degree of care which We use in respect to our own confidential and proprietary information of like nature, to prevent the unauthorized disclosure, reproduction or distribution of such Confidential Information to any other individual, corporation or entity. Such Confidential Information will exclude:\r\n(a)\tinformation that is already in the public domain;\r\n(b)\tinformation already known to the receiving party, as of the date of the disclosure, unless the receiving party agreed to keep such information in confidence at the time of its original receipt;\r\n(c)\tinformation hereafter obtained by the receiving party, from a source not otherwise under an obligation of confidentiality with the disclosing party;\r\n(d)\tinformation that the receiving party is obligated to produce under order of a court of competent jurisdiction, provided that the receiving party promptly notifies the disclosing party of such an event so that the disclosing party may seek an appropriate protective order.\r\n10. TERM\r\n10.1 Term. The term of this Agreement will commence on the date of Your agreement to these terms and shall continue for the same term as the Usage Agreement.\r\n11. GENERAL\r\n11.1 Consents. Any consent required under this Agreement will not be unreasonably withheld.\r\n11.2 Captions. The Article and paragraph headings used herein are for convenience only and are not a part of this Agreement and will not be used in construing it.\r\n11.3 Entire Agreement. This Agreement constitutes the entire agreement of the Parties, and no amendment to the terms of this Agreement will be effective unless in writing and signed by both parties hereto.\r\n11.4 Equitable Relief. You agree that any breach of this Agreement by You would cause irreparable damage, and that, in event of such breach, in addition to any and all remedies at law, We will have the right to an injunction, specific performance or other equitable relief to prevent the continuous violations of the terms of this Agreement.\r\n11.5 Force Majeure. Notwithstanding anything herein to the contrary, We shall not be liable for any delay or failure in performance caused by circumstances beyond Our reasonable control.\r\n11.6 Relationship of the Parties. This Agreement does not constitute a partnership or joint venture, and nothing herein contained is intended to constitute, nor will it be construed to constitute, such a partnership or joint venture. Except as expressly provided in this Agreement, neither We nor You will have any power or authority to act in the name or on behalf of the other party, or to bind the other party to any legal agreement.\r\n11.7 Severability. The provisions of this Agreement are to be considered separately, and if any provision hereof should be found by any court or competent jurisdiction to be invalid or unenforceable, this Agreement will be deemed to have effect as if such provision were severed from this Agreement.\r\n11.8 Number and Gender. Where the context permits, the singular includes the plural, and the masculine includes the feminine and vice versa.\r\n11.9 Notices. All notices and communications required or permitted under this Agreement will be in writing and will be sent by registered or certified mail, postage prepaid, return receipt requested, facsimile transmission (the “Fax”), with confirmed answer back, or electronic mail, with confirmation of receipt, to Us or You at the respective addresses we provide to each other or to such other address as We or You may \r\nfrom time to time specify by notice to the other given as provided in this paragraph. In Our case, Our address is:\r\n[complete with Licensor address, phone, fax and email]\r\nA notice given in electronic form shall be admissible in judicial or administrative proceedings based upon or relating to this Agreement to the same extent and subject to the same conditions as other business documents and records originally generated and maintained in printed form.\r\n11.10 JURISDICTION. THE PARTIES HEREBY IRREVOCABLY ATTORN TO THE EXCLUSIVE JURISDICTION OF THE COURTS OF THE PROVINCE OF [PROVINCE] WITH RESPECT TO ANY DISPUTE ARISING HEREUNDER.\r\n11.11 GOVERNING LAW. THIS AGREEMENT AND ANY SALES THEREUNDER SHALL BE DEEMED TO HAVE BEEN MADE IN THE PROVINCE OF ONTARIO AND SHALL BE CONSTRUED AND INTERPRETED ACCORDING TO THE LAWS OF THE PROVINCE OF [PROVINCE] AND THE APPLICABLE LAWS OF CANADA. We and You expressly exclude the United Nations Convention on Contracts for the International Sale of Goods, and the International Sale of Goods Act ([Province]), as amended, replaced or re-enacted from time to time.\r\n11.12 Revisions to this Agreement. We may at any time revise the terms of this Agreement by updating these terms and by providing notice to you of that change.\r\nTHIS AGREEMENT made as of the [_____] day of [________________], [20__].\r\nBETWEEN:\r\n[Customer]\r\n(“Customer”)\r\nOF THE FIRST PART\r\n- and -\r\n________________________\r\n(the “Vendor”)\r\nOF THE SECOND PART\r\n____________\r\n\r\n
\.


--
-- Name: licenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('licenses_id_seq', 1, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY schema_migrations (version) FROM stdin;
20140523191507
20140523191508
20140523191509
20140523191510
20140523191511
20140523191512
20140523191513
20140523191514
20140523191515
20140523191516
20140523191517
20140523191518
20140523191519
20140523191520
20140523191521
20140523191522
20140523191523
20140523191524
20140523191525
20140523191526
20140523191527
20140523191528
20140523191529
20140523191530
20140523191531
20140523191532
20140523191533
20140523191534
20140523191535
20140523191536
20140523191537
20140523191538
20140523191539
20140523191540
20140523191541
20140523191542
20140523191543
20140523191544
20140523191545
20140523191546
20140523191547
20140523191548
20140523191549
20140523191550
20140523191551
20140523191552
20140523191553
20140523191554
20140523191555
20140523191556
20140523191557
20140523191558
20140523191559
20140523191560
20140523191561
20140523191562
20140523191563
20140523191564
20140523191565
20140523191566
20140523191567
20140523191568
20140523191569
20140523191570
20140523191571
20140523191572
20140523191573
20140523191574
20140523191575
20140523191576
20140523191577
20140523191578
20140523191579
20140523191580
20140523191581
20140523191582
20140523191583
20140523191584
20140523191585
20140523191586
20140523191587
20140523191588
20140523191589
20140523191590
20140523191591
20140523191592
20140523191593
20140523191594
20140523191595
20140523191596
20140523191597
20140523191598
20140523191599
20140523191600
20140523191601
20140523191602
20140523191603
20140523191604
20140523191605
20140523191606
20140523191607
20140523191608
20140523191609
20140523191610
20140523191611
20140523191612
20140523191613
20140523191614
20140523191615
20140523191616
20140523191617
20140523191618
20140523191619
20140523191620
20140523191621
20140523191622
20140523191623
20140523191624
20140523191625
20140523191626
20140523191627
20140523191628
20140523191629
20140523191630
20140523191631
20140523191632
20140523191633
20140523191634
20140523191635
20140523191636
20140523191637
20140523191638
20140523191639
20140523191640
20140523191641
20140523191642
20140523191643
20140523191644
20140523191645
20140523191646
20140523191647
20140523191648
20140523191649
20140523191650
20140523191651
20140529205229
20140529205230
20141021135652
20141021135653
20141021135654
20141021135655
20141021135656
20141021135657
20141021135658
20141021135659
20141021135660
20141021135661
20141021135662
20141021135663
20141021135664
20141021135665
20141021135666
20141021135667
20141021135668
20141021135669
20141022140907
20141022141708
20141022153418
20141029171713
20141113152547
20141113154057
20141113175929
\.


--
-- Data for Name: spree_addresses; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_addresses (id, firstname, lastname, address1, address2, city, zipcode, phone, state_name, alternative_phone, company, state_id, country_id, created_at, updated_at) FROM stdin;
1	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:04:24.089023	2014-11-13 18:04:24.089023
2	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:04:24.136941	2014-11-13 18:04:24.136941
3	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:04:24.395831	2014-11-13 18:04:24.395831
4	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:04:24.418807	2014-11-13 18:04:24.418807
5	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:13:10.478413	2014-11-13 18:13:10.478413
6	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:13:10.480567	2014-11-13 18:13:10.480567
7	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:13:33.146561	2014-11-13 18:13:33.146561
8	Paul	Cook	3982 Powell Road	Suite 101	Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-13 18:13:33.148707	2014-11-13 18:13:33.148707
9	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:44:04.985483	2014-11-14 15:44:04.985483
10	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:44:05.216384	2014-11-14 15:44:05.216384
11	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:44:05.439696	2014-11-14 15:44:05.439696
12	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:44:05.481451	2014-11-14 15:44:05.481451
13	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:48:02.424269	2014-11-14 15:48:02.424269
14	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:48:02.426719	2014-11-14 15:48:02.426719
15	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:51:17.441658	2014-11-14 15:51:17.441658
16	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 15:51:17.443488	2014-11-14 15:51:17.443488
17	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 16:05:37.217559	2014-11-14 16:05:37.217559
18	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-14 16:05:37.223789	2014-11-14 16:05:37.223789
19	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-18 15:26:49.226288	2014-11-18 15:26:49.226288
20	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-18 15:40:17.384898	2014-11-18 15:40:17.384898
21	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 14:34:09.1711	2014-11-19 14:34:09.1711
22	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 14:35:35.485897	2014-11-19 14:35:35.485897
23	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:03:20.07134	2014-11-19 15:03:20.07134
24	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:03:30.910626	2014-11-19 15:03:30.910626
25	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:05:04.698768	2014-11-19 15:05:04.698768
26	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:05:14.292991	2014-11-19 15:05:14.292991
27	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:54:27.964088	2014-11-19 15:54:27.964088
28	Paul	Cook	3958 Hickory Rock Drive		Powell	43065	6144294364	\N	\N	\N	31	49	2014-11-19 15:54:51.755708	2014-11-19 15:54:51.755708
\.


--
-- Name: spree_addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_addresses_id_seq', 28, true);


--
-- Data for Name: spree_adjustments; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_adjustments (id, source_id, source_type, adjustable_id, adjustable_type, amount, label, mandatory, eligible, created_at, updated_at, state, order_id, included) FROM stdin;
\.


--
-- Name: spree_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_adjustments_id_seq', 1, false);


--
-- Data for Name: spree_assets; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_assets (id, viewable_id, viewable_type, attachment_width, attachment_height, attachment_file_size, "position", attachment_content_type, attachment_file_name, type, attachment_updated_at, alt, created_at, updated_at) FROM stdin;
3	6	Spree::Variant	175	175	9500	1	image/jpeg	buckeye-stroll.jpg	Spree::Image	2014-06-03 13:21:45.320725		\N	\N
4	7	Spree::Variant	175	175	9183	1	image/jpeg	mzl.hhjkjbnf.175x175-75.jpg	Spree::Image	2014-07-18 17:50:38.60366		\N	\N
5	8	Spree::Variant	175	175	9252	1	image/jpeg	mzl.uxrovacm.175x175-75.jpg	Spree::Image	2014-07-21 14:33:46.112207		\N	\N
6	9	Spree::Variant	175	175	4555	1	image/jpeg	mzl.msxucena.175x175-75.jpg	Spree::Image	2014-07-21 14:38:39.863413		\N	\N
7	10	Spree::Variant	175	175	9777	1	image/jpeg	mzl.alvkjgyy.175x175-75.jpg	Spree::Image	2014-07-21 14:41:54.846779		\N	\N
8	11	Spree::Variant	175	175	10810	1	image/jpeg	mzl.sixmagiw.175x175-75.jpg	Spree::Image	2014-07-21 14:54:55.827456		\N	\N
9	12	Spree::Variant	175	175	8222	1	image/jpeg	mzl.ytmanxqs.175x175-75.jpg	Spree::Image	2014-07-21 15:03:13.020292		\N	\N
10	13	Spree::Variant	175	175	6852	1	image/jpeg	mzl.vyfvrpjh.175x175-75.jpg	Spree::Image	2014-07-21 15:32:29.469826		\N	\N
11	14	Spree::Variant	175	175	15825	1	image/jpeg	mzl.ovfqffhb.175x175-75.jpg	Spree::Image	2014-07-21 16:49:13.795837		\N	\N
12	15	Spree::Variant	175	175	19740	1	image/jpeg	mzl.yhbhhgtf.175x175-75.jpg	Spree::Image	2014-07-21 16:50:41.838948		\N	\N
13	16	Spree::Variant	175	175	13353	1	image/jpeg	mzl.eeuriweg.175x175-75.jpg	Spree::Image	2014-07-21 16:52:01.926818		\N	\N
14	17	Spree::Variant	117	117	2859	1	image/jpeg	search-1.jpg	Spree::Image	2014-07-22 17:45:33.284249		\N	\N
15	29	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 17:49:28.921756		\N	\N
16	18	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 17:54:35.54393		\N	\N
17	22	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 18:02:46.519204		\N	\N
18	23	Spree::Variant	225	225	7672	1	image/jpeg	images-2.jpg	Spree::Image	2014-07-22 18:04:12.389459		\N	\N
19	26	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 18:08:21.909146		\N	\N
20	21	Spree::Variant	225	225	7672	1	image/jpeg	images-2.jpg	Spree::Image	2014-07-22 18:22:27.967206		\N	\N
21	20	Spree::Variant	124	124	4870	1	image/jpeg	images-3.jpg	Spree::Image	2014-07-22 18:49:23.644535		\N	\N
22	28	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 18:50:10.734309		\N	\N
23	25	Spree::Variant	225	225	7672	1	image/jpeg	images-2.jpg	Spree::Image	2014-07-22 18:51:32.893852		\N	\N
24	19	Spree::Variant	114	104	2467	1	image/jpeg	imgres-1.jpg	Spree::Image	2014-07-22 18:52:07.877311		\N	\N
25	24	Spree::Variant	117	117	2859	1	image/jpeg	search-1.jpg	Spree::Image	2014-07-22 18:52:56.825686		\N	\N
\.


--
-- Name: spree_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_assets_id_seq', 1, false);


--
-- Data for Name: spree_calculators; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_calculators (id, type, calculable_id, calculable_type, created_at, updated_at, preferences) FROM stdin;
1	Spree::Calculator::Shipping::DigitalDelivery	1	Spree::ShippingMethod	2014-05-30 13:57:17.484488	2014-10-23 13:33:58.020628	---\n:amount: !ruby/object:BigDecimal 18:0.0\n:currency: USD\n
\.


--
-- Name: spree_calculators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_calculators_id_seq', 1, false);


--
-- Data for Name: spree_configurations; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_configurations (id, name, type, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_configurations_id_seq', 1, false);


--
-- Data for Name: spree_countries; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_countries (id, iso_name, iso, iso3, name, numcode, states_required, updated_at) FROM stdin;
1	CHAD	TD	TCD	Chad	148	f	2014-05-29 20:20:14.711842
2	FAROE ISLANDS	FO	FRO	Faroe Islands	234	f	2014-05-29 20:20:14.71759
3	INDIA	IN	IND	India	356	t	2014-05-29 20:20:14.721792
4	NICARAGUA	NI	NIC	Nicaragua	558	f	2014-05-29 20:20:14.725902
5	SAINT LUCIA	LC	LCA	Saint Lucia	662	f	2014-05-29 20:20:14.72999
6	FIJI	FJ	FJI	Fiji	242	f	2014-05-29 20:20:14.73393
7	INDONESIA	ID	IDN	Indonesia	360	f	2014-05-29 20:20:14.737854
8	NIGER	NE	NER	Niger	562	f	2014-05-29 20:20:14.741919
9	SAINT PIERRE AND MIQUELON	PM	SPM	Saint Pierre and Miquelon	666	f	2014-05-29 20:20:14.746002
10	FINLAND	FI	FIN	Finland	246	f	2014-05-29 20:20:14.749981
11	NIGERIA	NG	NGA	Nigeria	566	t	2014-05-29 20:20:14.753956
12	SAINT VINCENT AND THE GRENADINES	VC	VCT	Saint Vincent and the Grenadines	670	f	2014-05-29 20:20:14.758416
13	FRANCE	FR	FRA	France	250	f	2014-05-29 20:20:14.762412
14	IRAN, ISLAMIC REPUBLIC OF	IR	IRN	Iran, Islamic Republic of	364	f	2014-05-29 20:20:14.766467
15	NIUE	NU	NIU	Niue	570	f	2014-05-29 20:20:14.770536
16	SAMOA	WS	WSM	Samoa	882	f	2014-05-29 20:20:14.775971
17	FRENCH GUIANA	GF	GUF	French Guiana	254	f	2014-05-29 20:20:14.780412
18	IRAQ	IQ	IRQ	Iraq	368	t	2014-05-29 20:20:14.784402
19	SAN MARINO	SM	SMR	San Marino	674	f	2014-05-29 20:20:14.788464
20	IRELAND	IE	IRL	Ireland	372	f	2014-05-29 20:20:14.792321
21	SAO TOME AND PRINCIPE	ST	STP	Sao Tome and Principe	678	f	2014-05-29 20:20:14.796138
22	ISRAEL	IL	ISR	Israel	376	f	2014-05-29 20:20:14.799999
23	SAUDI ARABIA	SA	SAU	Saudi Arabia	682	f	2014-05-29 20:20:14.804014
24	ITALY	IT	ITA	Italy	380	f	2014-05-29 20:20:14.807992
25	SENEGAL	SN	SEN	Senegal	686	f	2014-05-29 20:20:14.811885
26	JAMAICA	JM	JAM	Jamaica	388	f	2014-05-29 20:20:14.815862
27	JAPAN	JP	JPN	Japan	392	f	2014-05-29 20:20:14.820255
28	JORDAN	JO	JOR	Jordan	400	f	2014-05-29 20:20:14.825894
29	BELGIUM	BE	BEL	Belgium	56	f	2014-05-29 20:20:14.831773
30	BELIZE	BZ	BLZ	Belize	84	f	2014-05-29 20:20:14.83582
31	KAZAKHSTAN	KZ	KAZ	Kazakhstan	398	f	2014-05-29 20:20:14.839728
32	UGANDA	UG	UGA	Uganda	800	f	2014-05-29 20:20:14.844796
33	BENIN	BJ	BEN	Benin	204	f	2014-05-29 20:20:14.848756
34	KENYA	KE	KEN	Kenya	404	f	2014-05-29 20:20:14.85275
35	UKRAINE	UA	UKR	Ukraine	804	f	2014-05-29 20:20:14.856702
36	BERMUDA	BM	BMU	Bermuda	60	f	2014-05-29 20:20:14.860624
37	KIRIBATI	KI	KIR	Kiribati	296	f	2014-05-29 20:20:14.864599
38	MEXICO	MX	MEX	Mexico	484	t	2014-05-29 20:20:14.868579
39	UNITED ARAB EMIRATES	AE	ARE	United Arab Emirates	784	t	2014-05-29 20:20:14.87274
40	BHUTAN	BT	BTN	Bhutan	64	f	2014-05-29 20:20:14.876696
41	CUBA	CU	CUB	Cuba	192	f	2014-05-29 20:20:14.88067
42	KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF	KP	PRK	North Korea	408	f	2014-05-29 20:20:14.884597
43	MICRONESIA, FEDERATED STATES OF	FM	FSM	Micronesia, Federated States of	583	t	2014-05-29 20:20:14.888587
44	UNITED KINGDOM	GB	GBR	United Kingdom	826	f	2014-05-29 20:20:14.892717
45	BOLIVIA	BO	BOL	Bolivia	68	f	2014-05-29 20:20:14.896735
46	CYPRUS	CY	CYP	Cyprus	196	f	2014-05-29 20:20:14.901768
47	KOREA, REPUBLIC OF	KR	KOR	South Korea	410	f	2014-05-29 20:20:14.905733
48	MOLDOVA, REPUBLIC OF	MD	MDA	Moldova, Republic of	498	f	2014-05-29 20:20:14.909604
49	UNITED STATES	US	USA	United States	840	t	2014-05-29 20:20:14.913597
50	BOSNIA AND HERZEGOVINA	BA	BIH	Bosnia and Herzegovina	70	f	2014-05-29 20:20:14.917543
51	CZECH REPUBLIC	CZ	CZE	Czech Republic	203	f	2014-05-29 20:20:14.92144
52	KUWAIT	KW	KWT	Kuwait	414	f	2014-05-29 20:20:14.925442
53	MONACO	MC	MCO	Monaco	492	f	2014-05-29 20:20:14.929444
54	URUGUAY	UY	URY	Uruguay	858	f	2014-05-29 20:20:14.933267
55	BOTSWANA	BW	BWA	Botswana	72	f	2014-05-29 20:20:14.937137
56	DENMARK	DK	DNK	Denmark	208	f	2014-05-29 20:20:14.94099
57	GUADELOUPE	GP	GLP	Guadeloupe	312	f	2014-05-29 20:20:14.94486
58	KYRGYZSTAN	KG	KGZ	Kyrgyzstan	417	f	2014-05-29 20:20:14.948695
59	MONGOLIA	MN	MNG	Mongolia	496	f	2014-05-29 20:20:14.952637
60	PHILIPPINES	PH	PHL	Philippines	608	f	2014-05-29 20:20:14.957699
61	BRAZIL	BR	BRA	Brazil	76	t	2014-05-29 20:20:14.961651
62	DJIBOUTI	DJ	DJI	Djibouti	262	f	2014-05-29 20:20:14.965674
63	GUAM	GU	GUM	Guam	316	f	2014-05-29 20:20:14.969574
64	LAO PEOPLE'S DEMOCRATIC REPUBLIC	LA	LAO	Lao People's Democratic Republic	418	f	2014-05-29 20:20:14.973454
65	MONTSERRAT	MS	MSR	Montserrat	500	f	2014-05-29 20:20:14.977984
66	PITCAIRN	PN	PCN	Pitcairn	612	f	2014-05-29 20:20:14.981952
67	UZBEKISTAN	UZ	UZB	Uzbekistan	860	f	2014-05-29 20:20:14.985993
68	BRUNEI DARUSSALAM	BN	BRN	Brunei Darussalam	96	f	2014-05-29 20:20:14.989977
69	DOMINICA	DM	DMA	Dominica	212	f	2014-05-29 20:20:14.994043
70	GUATEMALA	GT	GTM	Guatemala	320	f	2014-05-29 20:20:14.998396
71	MOROCCO	MA	MAR	Morocco	504	f	2014-05-29 20:20:15.002254
72	POLAND	PL	POL	Poland	616	f	2014-05-29 20:20:15.006174
73	VANUATU	VU	VUT	Vanuatu	548	f	2014-05-29 20:20:15.010074
74	DOMINICAN REPUBLIC	DO	DOM	Dominican Republic	214	f	2014-05-29 20:20:15.014299
75	MOZAMBIQUE	MZ	MOZ	Mozambique	508	f	2014-05-29 20:20:15.019141
76	PORTUGAL	PT	PRT	Portugal	620	f	2014-05-29 20:20:15.023061
77	SUDAN	SD	SDN	Sudan	736	t	2014-05-29 20:20:15.027199
78	VENEZUELA	VE	VEN	Venezuela	862	t	2014-05-29 20:20:15.031117
79	ECUADOR	EC	ECU	Ecuador	218	f	2014-05-29 20:20:15.034981
80	GUINEA	GN	GIN	Guinea	324	f	2014-05-29 20:20:15.038896
81	MYANMAR	MM	MMR	Myanmar	104	f	2014-05-29 20:20:15.05414
82	PUERTO RICO	PR	PRI	Puerto Rico	630	f	2014-05-29 20:20:15.057962
83	SURINAME	SR	SUR	Suriname	740	f	2014-05-29 20:20:15.06175
84	VIET NAM	VN	VNM	Viet Nam	704	f	2014-05-29 20:20:15.065664
85	EGYPT	EG	EGY	Egypt	818	f	2014-05-29 20:20:15.069626
86	GUINEA-BISSAU	GW	GNB	Guinea-Bissau	624	f	2014-05-29 20:20:15.073534
87	NAMIBIA	NA	NAM	Namibia	516	f	2014-05-29 20:20:15.077424
88	QATAR	QA	QAT	Qatar	634	f	2014-05-29 20:20:15.081286
89	SVALBARD AND JAN MAYEN	SJ	SJM	Svalbard and Jan Mayen	744	f	2014-05-29 20:20:15.085165
90	EL SALVADOR	SV	SLV	El Salvador	222	f	2014-05-29 20:20:15.090091
91	GUYANA	GY	GUY	Guyana	328	f	2014-05-29 20:20:15.093932
92	REUNION	RE	REU	Reunion	638	f	2014-05-29 20:20:15.097736
93	HAITI	HT	HTI	Haiti	332	f	2014-05-29 20:20:15.101682
94	ROMANIA	RO	ROM	Romania	642	f	2014-05-29 20:20:15.10554
95	SWAZILAND	SZ	SWZ	Swaziland	748	f	2014-05-29 20:20:15.109309
96	HOLY SEE (VATICAN CITY STATE)	VA	VAT	Holy See (Vatican City State)	336	f	2014-05-29 20:20:15.113091
97	RUSSIAN FEDERATION	RU	RUS	Russian Federation	643	t	2014-05-29 20:20:15.117035
98	SWEDEN	SE	SWE	Sweden	752	f	2014-05-29 20:20:15.121186
99	HONDURAS	HN	HND	Honduras	340	f	2014-05-29 20:20:15.125195
100	RWANDA	RW	RWA	Rwanda	646	f	2014-05-29 20:20:15.129208
101	SWITZERLAND	CH	CHE	Switzerland	756	f	2014-05-29 20:20:15.133277
102	HONG KONG	HK	HKG	Hong Kong	344	f	2014-05-29 20:20:15.13715
103	SYRIAN ARAB REPUBLIC	SY	SYR	Syrian Arab Republic	760	f	2014-05-29 20:20:15.140934
104	TAIWAN, PROVINCE OF CHINA	TW	TWN	Taiwan	158	f	2014-05-29 20:20:15.145762
105	TAJIKISTAN	TJ	TJK	Tajikistan	762	f	2014-05-29 20:20:15.14962
106	TANZANIA, UNITED REPUBLIC OF	TZ	TZA	Tanzania, United Republic of	834	f	2014-05-29 20:20:15.15344
107	ARMENIA	AM	ARM	Armenia	51	f	2014-05-29 20:20:15.157286
108	ARUBA	AW	ABW	Aruba	533	f	2014-05-29 20:20:15.161082
109	AUSTRALIA	AU	AUS	Australia	36	t	2014-05-29 20:20:15.164893
110	THAILAND	TH	THA	Thailand	764	f	2014-05-29 20:20:15.168863
111	AUSTRIA	AT	AUT	Austria	40	f	2014-05-29 20:20:15.17274
112	MADAGASCAR	MG	MDG	Madagascar	450	f	2014-05-29 20:20:15.176781
113	TOGO	TG	TGO	Togo	768	f	2014-05-29 20:20:15.180698
114	AZERBAIJAN	AZ	AZE	Azerbaijan	31	f	2014-05-29 20:20:15.184556
115	CHILE	CL	CHL	Chile	152	f	2014-05-29 20:20:15.188428
116	MALAWI	MW	MWI	Malawi	454	f	2014-05-29 20:20:15.192211
117	TOKELAU	TK	TKL	Tokelau	772	f	2014-05-29 20:20:15.196257
118	BAHAMAS	BS	BHS	Bahamas	44	f	2014-05-29 20:20:15.200649
119	CHINA	CN	CHN	China	156	f	2014-05-29 20:20:15.205495
120	MALAYSIA	MY	MYS	Malaysia	458	f	2014-05-29 20:20:15.209373
121	TONGA	TO	TON	Tonga	776	f	2014-05-29 20:20:15.213631
122	BAHRAIN	BH	BHR	Bahrain	48	f	2014-05-29 20:20:15.217573
123	COLOMBIA	CO	COL	Colombia	170	f	2014-05-29 20:20:15.221468
124	MALDIVES	MV	MDV	Maldives	462	f	2014-05-29 20:20:15.225545
125	TRINIDAD AND TOBAGO	TT	TTO	Trinidad and Tobago	780	f	2014-05-29 20:20:15.229499
126	BANGLADESH	BD	BGD	Bangladesh	50	f	2014-05-29 20:20:15.233361
127	COMOROS	KM	COM	Comoros	174	t	2014-05-29 20:20:15.237217
128	FRENCH POLYNESIA	PF	PYF	French Polynesia	258	f	2014-05-29 20:20:15.241212
129	MALI	ML	MLI	Mali	466	f	2014-05-29 20:20:15.24531
130	NORFOLK ISLAND	NF	NFK	Norfolk Island	574	f	2014-05-29 20:20:15.249205
131	TUNISIA	TN	TUN	Tunisia	788	f	2014-05-29 20:20:15.253088
132	BARBADOS	BB	BRB	Barbados	52	f	2014-05-29 20:20:15.257058
133	CONGO	CG	COG	Congo	178	f	2014-05-29 20:20:15.260993
134	GABON	GA	GAB	Gabon	266	f	2014-05-29 20:20:15.265939
135	MALTA	MT	MLT	Malta	470	f	2014-05-29 20:20:15.269818
136	NORTHERN MARIANA ISLANDS	MP	MNP	Northern Mariana Islands	580	f	2014-05-29 20:20:15.273899
137	TURKEY	TR	TUR	Turkey	792	f	2014-05-29 20:20:15.277819
138	CONGO, THE DEMOCRATIC REPUBLIC OF THE	CD	COD	Congo, the Democratic Republic of the	180	f	2014-05-29 20:20:15.281778
139	MARSHALL ISLANDS	MH	MHL	Marshall Islands	584	f	2014-05-29 20:20:15.285726
140	NORWAY	NO	NOR	Norway	578	f	2014-05-29 20:20:15.290248
141	TURKMENISTAN	TM	TKM	Turkmenistan	795	f	2014-05-29 20:20:15.294201
142	BELARUS	BY	BLR	Belarus	112	f	2014-05-29 20:20:15.298127
143	COOK ISLANDS	CK	COK	Cook Islands	184	f	2014-05-29 20:20:15.317733
144	GAMBIA	GM	GMB	Gambia	270	f	2014-05-29 20:20:15.322289
145	MARTINIQUE	MQ	MTQ	Martinique	474	f	2014-05-29 20:20:15.326146
146	OMAN	OM	OMN	Oman	512	f	2014-05-29 20:20:15.329955
147	SEYCHELLES	SC	SYC	Seychelles	690	f	2014-05-29 20:20:15.333903
148	TURKS AND CAICOS ISLANDS	TC	TCA	Turks and Caicos Islands	796	f	2014-05-29 20:20:15.338834
149	GEORGIA	GE	GEO	Georgia	268	f	2014-05-29 20:20:15.343015
150	MAURITANIA	MR	MRT	Mauritania	478	f	2014-05-29 20:20:15.346881
151	PAKISTAN	PK	PAK	Pakistan	586	t	2014-05-29 20:20:15.350807
152	SIERRA LEONE	SL	SLE	Sierra Leone	694	f	2014-05-29 20:20:15.354834
153	TUVALU	TV	TUV	Tuvalu	798	f	2014-05-29 20:20:15.358753
154	COSTA RICA	CR	CRI	Costa Rica	188	f	2014-05-29 20:20:15.362784
155	GERMANY	DE	DEU	Germany	276	f	2014-05-29 20:20:15.366789
156	MAURITIUS	MU	MUS	Mauritius	480	f	2014-05-29 20:20:15.370782
157	PALAU	PW	PLW	Palau	585	f	2014-05-29 20:20:15.374819
158	COTE D'IVOIRE	CI	CIV	Cote D'Ivoire	384	f	2014-05-29 20:20:15.378705
159	PANAMA	PA	PAN	Panama	591	f	2014-05-29 20:20:15.382771
160	SINGAPORE	SG	SGP	Singapore	702	f	2014-05-29 20:20:15.386617
161	CROATIA	HR	HRV	Croatia	191	f	2014-05-29 20:20:15.390519
162	GHANA	GH	GHA	Ghana	288	f	2014-05-29 20:20:15.394364
163	PAPUA NEW GUINEA	PG	PNG	Papua New Guinea	598	f	2014-05-29 20:20:15.399438
164	SLOVAKIA	SK	SVK	Slovakia	703	f	2014-05-29 20:20:15.40348
165	GIBRALTAR	GI	GIB	Gibraltar	292	f	2014-05-29 20:20:15.407317
166	PARAGUAY	PY	PRY	Paraguay	600	f	2014-05-29 20:20:15.411112
167	SLOVENIA	SI	SVN	Slovenia	705	f	2014-05-29 20:20:15.414915
168	GREECE	GR	GRC	Greece	300	f	2014-05-29 20:20:15.419011
169	PERU	PE	PER	Peru	604	f	2014-05-29 20:20:15.422859
170	SOLOMON ISLANDS	SB	SLB	Solomon Islands	90	f	2014-05-29 20:20:15.426965
171	GREENLAND	GL	GRL	Greenland	304	f	2014-05-29 20:20:15.431131
172	SOMALIA	SO	SOM	Somalia	706	t	2014-05-29 20:20:15.434931
173	GRENADA	GD	GRD	Grenada	308	f	2014-05-29 20:20:15.43878
174	SOUTH AFRICA	ZA	ZAF	South Africa	710	f	2014-05-29 20:20:15.442558
175	SPAIN	ES	ESP	Spain	724	f	2014-05-29 20:20:15.446387
176	SRI LANKA	LK	LKA	Sri Lanka	144	f	2014-05-29 20:20:15.45015
177	AFGHANISTAN	AF	AFG	Afghanistan	4	f	2014-05-29 20:20:15.453925
178	ALBANIA	AL	ALB	Albania	8	f	2014-05-29 20:20:15.458718
179	ALGERIA	DZ	DZA	Algeria	12	f	2014-05-29 20:20:15.462729
180	LATVIA	LV	LVA	Latvia	428	f	2014-05-29 20:20:15.467172
181	AMERICAN SAMOA	AS	ASM	American Samoa	16	f	2014-05-29 20:20:15.470946
182	BULGARIA	BG	BGR	Bulgaria	100	f	2014-05-29 20:20:15.4748
183	LEBANON	LB	LBN	Lebanon	422	f	2014-05-29 20:20:15.478831
184	ANDORRA	AD	AND	Andorra	20	f	2014-05-29 20:20:15.482988
185	BURKINA FASO	BF	BFA	Burkina Faso	854	f	2014-05-29 20:20:15.487027
186	LESOTHO	LS	LSO	Lesotho	426	f	2014-05-29 20:20:15.490922
187	ANGOLA	AO	AGO	Angola	24	f	2014-05-29 20:20:15.49481
188	BURUNDI	BI	BDI	Burundi	108	f	2014-05-29 20:20:15.498763
189	LIBERIA	LR	LBR	Liberia	430	f	2014-05-29 20:20:15.502559
190	VIRGIN ISLANDS, BRITISH	VG	VGB	Virgin Islands, British	92	f	2014-05-29 20:20:15.507057
191	ANGUILLA	AI	AIA	Anguilla	660	f	2014-05-29 20:20:15.511198
192	CAMBODIA	KH	KHM	Cambodia	116	f	2014-05-29 20:20:15.515255
193	EQUATORIAL GUINEA	GQ	GNQ	Equatorial Guinea	226	f	2014-05-29 20:20:15.520228
194	LIBYAN ARAB JAMAHIRIYA	LY	LBY	Libyan Arab Jamahiriya	434	f	2014-05-29 20:20:15.524233
195	NAURU	NR	NRU	Nauru	520	f	2014-05-29 20:20:15.528122
196	VIRGIN ISLANDS, U.S.	VI	VIR	Virgin Islands, U.S.	850	f	2014-05-29 20:20:15.531817
197	ANTIGUA AND BARBUDA	AG	ATG	Antigua and Barbuda	28	f	2014-05-29 20:20:15.53584
198	CAMEROON	CM	CMR	Cameroon	120	f	2014-05-29 20:20:15.539851
199	LIECHTENSTEIN	LI	LIE	Liechtenstein	438	f	2014-05-29 20:20:15.543764
200	NEPAL	NP	NPL	Nepal	524	t	2014-05-29 20:20:15.547617
201	WALLIS AND FUTUNA	WF	WLF	Wallis and Futuna	876	f	2014-05-29 20:20:15.551569
202	WESTERN SAHARA	EH	ESH	Western Sahara	732	f	2014-05-29 20:20:15.555409
203	ARGENTINA	AR	ARG	Argentina	32	f	2014-05-29 20:20:15.559235
204	CANADA	CA	CAN	Canada	124	t	2014-05-29 20:20:15.563004
205	ERITREA	ER	ERI	Eritrea	232	f	2014-05-29 20:20:15.566903
206	LITHUANIA	LT	LTU	Lithuania	440	f	2014-05-29 20:20:15.570831
207	NETHERLANDS	NL	NLD	Netherlands	528	f	2014-05-29 20:20:15.575733
208	YEMEN	YE	YEM	Yemen	887	f	2014-05-29 20:20:15.579684
209	CAPE VERDE	CV	CPV	Cape Verde	132	f	2014-05-29 20:20:15.583568
210	ESTONIA	EE	EST	Estonia	233	f	2014-05-29 20:20:15.587551
211	LUXEMBOURG	LU	LUX	Luxembourg	442	f	2014-05-29 20:20:15.591387
212	NETHERLANDS ANTILLES	AN	ANT	Netherlands Antilles	530	f	2014-05-29 20:20:15.627222
213	SAINT HELENA	SH	SHN	Saint Helena	654	f	2014-05-29 20:20:15.647314
214	ZAMBIA	ZM	ZMB	Zambia	894	f	2014-05-29 20:20:15.651461
215	CAYMAN ISLANDS	KY	CYM	Cayman Islands	136	f	2014-05-29 20:20:15.655361
216	ETHIOPIA	ET	ETH	Ethiopia	231	t	2014-05-29 20:20:15.659245
217	HUNGARY	HU	HUN	Hungary	348	f	2014-05-29 20:20:15.663205
218	MACAO	MO	MAC	Macao	446	f	2014-05-29 20:20:15.667441
219	NEW CALEDONIA	NC	NCL	New Caledonia	540	f	2014-05-29 20:20:15.671658
220	ZIMBABWE	ZW	ZWE	Zimbabwe	716	f	2014-05-29 20:20:15.67574
221	CENTRAL AFRICAN REPUBLIC	CF	CAF	Central African Republic	140	f	2014-05-29 20:20:15.679675
222	FALKLAND ISLANDS (MALVINAS)	FK	FLK	Falkland Islands (Malvinas)	238	f	2014-05-29 20:20:15.684787
223	ICELAND	IS	ISL	Iceland	352	f	2014-05-29 20:20:15.688707
224	MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF	MK	MKD	Macedonia	807	f	2014-05-29 20:20:15.692812
225	NEW ZEALAND	NZ	NZL	New Zealand	554	f	2014-05-29 20:20:15.696766
226	SAINT KITTS AND NEVIS	KN	KNA	Saint Kitts and Nevis	659	t	2014-05-29 20:20:15.700752
227	SERBIA	RS	SRB	Serbia	999	f	2014-05-29 20:20:15.704557
228	MONTENEGRO	ME	MNE	Montenegro	499	f	2014-05-29 20:20:15.708795
\.


--
-- Name: spree_countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_countries_id_seq', 1, false);


--
-- Data for Name: spree_credit_cards; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_credit_cards (id, month, year, cc_type, last_digits, address_id, gateway_customer_profile_id, gateway_payment_profile_id, created_at, updated_at, name, user_id, payment_method_id) FROM stdin;
\.


--
-- Name: spree_credit_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_credit_cards_id_seq', 1, false);


--
-- Data for Name: spree_digital_links; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_digital_links (id, digital_id, line_item_id, secret, access_counter, created_at, updated_at) FROM stdin;
1	2	1	b2559c528a99cbe7cd37f1ef3ddb20	0	2014-07-18 17:47:03.525016	2014-07-18 17:47:03.525016
3	3	8	f68a72cfbf7fcbc687e13e8f13d56a	1	2014-11-18 15:26:21.438558	2014-11-18 15:57:24.933266
4	2	9	66eac79259c4557e224f08ef98f08d	0	2014-11-19 14:33:55.714138	2014-11-19 14:33:55.714138
\.


--
-- Name: spree_digital_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_digital_links_id_seq', 4, true);


--
-- Data for Name: spree_digitals; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_digitals (id, variant_id, attachment_file_name, attachment_content_type, attachment_file_size, created_at, updated_at) FROM stdin;
2	15	DJRTD_eBook.pdf	application/pdf	5524503	2014-11-14 16:21:53.341844	2014-11-14 16:21:53.341844
3	29	DJRTD_eBook.pdf	application/pdf	5524503	2014-11-18 14:35:16.963037	2014-11-18 14:35:16.963037
\.


--
-- Name: spree_digitals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_digitals_id_seq', 3, true);


--
-- Data for Name: spree_gateways; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_gateways (id, type, name, description, active, environment, server, test_mode, created_at, updated_at, preferences) FROM stdin;
\.


--
-- Name: spree_gateways_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_gateways_id_seq', 1, false);


--
-- Data for Name: spree_inventory_units; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_inventory_units (id, state, variant_id, order_id, shipment_id, return_authorization_id, created_at, updated_at, pending, line_item_id) FROM stdin;
1	backordered	8	3	1	\N	2014-11-13 18:04:25.003467	2014-11-13 18:04:25.003467	t	5
2	backordered	8	3	2	\N	2014-11-13 18:11:35.521821	2014-11-13 18:11:35.521821	t	5
3	backordered	8	3	3	\N	2014-11-13 18:13:10.574529	2014-11-13 18:13:10.574529	t	5
4	backordered	8	3	4	\N	2014-11-13 18:13:33.82908	2014-11-13 18:13:33.82908	t	5
5	backordered	15	4	5	\N	2014-11-14 15:44:06.094241	2014-11-14 15:44:06.094241	t	6
6	backordered	15	4	6	\N	2014-11-14 15:48:02.885485	2014-11-14 15:48:02.885485	t	6
7	backordered	15	4	7	\N	2014-11-14 15:51:17.507348	2014-11-14 15:51:17.507348	t	6
\.


--
-- Name: spree_inventory_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_inventory_units_id_seq', 7, true);


--
-- Data for Name: spree_line_items; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_line_items (id, variant_id, order_id, quantity, price, created_at, updated_at, currency, cost_price, tax_category_id, adjustment_total, additional_tax_total, promo_total, included_tax_total, pre_tax_amount) FROM stdin;
1	2	1	1	50.00	2014-07-18 17:47:03.462233	2014-07-18 17:47:03.572857	USD	\N	1	0.00	0.00	0.00	0.00	\N
6	15	4	1	2.99	2014-11-14 15:41:22.125129	2014-11-14 15:41:22.645533	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
8	29	5	1	399.00	2014-11-18 15:26:21.395413	2014-11-18 15:26:21.57635	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
9	15	6	1	2.99	2014-11-19 14:33:54.075231	2014-11-19 14:33:56.844842	USD	\N	1	0.00	0.00	0.00	0.00	0.00
10	26	7	1	0.00	2014-11-19 15:02:42.222127	2014-11-19 15:02:42.383451	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
11	11	7	1	0.00	2014-11-19 15:03:14.086036	2014-11-19 15:03:14.250425	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
12	12	8	1	0.00	2014-11-19 15:04:33.850344	2014-11-19 15:04:33.920176	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
13	14	8	1	0.00	2014-11-19 15:04:59.568971	2014-11-19 15:04:59.625932	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
14	10	9	1	0.00	2014-11-19 15:54:22.044872	2014-11-19 15:54:22.233931	USD	\N	\N	0.00	0.00	0.00	0.00	0.00
\.


--
-- Name: spree_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_line_items_id_seq', 14, true);


--
-- Data for Name: spree_log_entries; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_log_entries (id, source_id, source_type, details, created_at, updated_at) FROM stdin;
1	2	Spree::Payment	--- !ruby/object:ActiveMerchant::Billing::Response\nparams: {}\nmessage: ''\nsuccess: true\ntest: false\nauthorization: \nfraud_review: \navs_result:\n  code: \n  message: \n  street_match: \n  postal_match: \ncvv_result:\n  code: \n  message: \n	2014-11-13 18:11:52.812793	2014-11-13 18:11:52.812793
2	3	Spree::Payment	--- !ruby/object:ActiveMerchant::Billing::Response\nparams: {}\nmessage: ''\nsuccess: true\ntest: false\nauthorization: \nfraud_review: \navs_result:\n  code: \n  message: \n  street_match: \n  postal_match: \ncvv_result:\n  code: \n  message: \n	2014-11-14 16:07:55.967249	2014-11-14 16:07:55.967249
3	4	Spree::Payment	--- !ruby/object:ActiveMerchant::Billing::Response\nparams: {}\nmessage: ''\nsuccess: true\ntest: false\nauthorization: \nfraud_review: \navs_result:\n  code: \n  message: \n  street_match: \n  postal_match: \ncvv_result:\n  code: \n  message: \n	2014-11-18 15:56:34.446234	2014-11-18 15:56:34.446234
\.


--
-- Name: spree_log_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_log_entries_id_seq', 3, true);


--
-- Data for Name: spree_option_types; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_option_types (id, name, presentation, "position", created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_option_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_option_types_id_seq', 1, false);


--
-- Data for Name: spree_option_types_prototypes; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_option_types_prototypes (prototype_id, option_type_id) FROM stdin;
\.


--
-- Data for Name: spree_option_values; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_option_values (id, "position", name, presentation, option_type_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_option_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_option_values_id_seq', 1, false);


--
-- Data for Name: spree_option_values_variants; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_option_values_variants (variant_id, option_value_id) FROM stdin;
\.


--
-- Data for Name: spree_orders; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_orders (id, number, item_total, total, state, adjustment_total, user_id, completed_at, bill_address_id, ship_address_id, payment_total, shipping_method_id, shipment_state, payment_state, email, special_instructions, created_at, updated_at, currency, last_ip_address, created_by_id, shipment_total, additional_tax_total, promo_total, channel, included_tax_total, item_count, approver_id, approved_at, confirmation_delivered, considered_risky, guest_token, state_lock_version) FROM stdin;
6	R699985533	2.99	2.99	complete	0.00	1	2014-11-19 14:35:47.53924	22	\N	0.00	\N	\N	balance_due	paul.pwc@gmail.com	\N	2014-11-19 14:33:52.503992	2014-11-19 14:35:47.53924	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	1	\N	\N	t	f	7RrujYcbC0do1bI92-o20w	0
8	R057528246	0.00	0.00	complete	0.00	1	2014-11-19 15:05:14.350486	26	\N	0.00	\N	\N	paid	paul.pwc@gmail.com	\N	2014-11-19 15:04:33.828855	2014-11-19 15:05:14.350486	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	2	\N	\N	t	f	7RrujYcbC0do1bI92-o20w	0
5	R131438906	399.00	399.00	complete	0.00	1	2014-11-18 15:40:30.795539	20	\N	399.00	\N	\N	paid	paul.pwc@gmail.com	\N	2014-11-18 14:37:17.988591	2014-11-18 15:56:34.470251	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	1	\N	\N	t	f	7RrujYcbC0do1bI92-o20w	0
4	R941721576	2.99	2.99	complete	0.00	1	2014-11-14 16:06:35.22728	17	18	2.99	\N	\N	paid	paul.pwc@gmail.com	\N	2014-11-14 15:41:21.830712	2014-11-14 16:07:55.995913	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	1	\N	\N	t	f	7RrujYcbC0do1bI92-o20w	0
7	R044412162	0.00	0.00	complete	0.00	1	2014-11-19 15:03:30.970328	24	\N	0.00	\N	\N	paid	paul.pwc@gmail.com	\N	2014-11-19 15:02:42.000336	2014-11-19 15:03:30.970328	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	2	\N	\N	f	f	7RrujYcbC0do1bI92-o20w	0
9	R957220870	0.00	0.00	complete	0.00	1	2014-11-19 15:54:51.795247	28	\N	0.00	\N	\N	paid	paul.pwc@gmail.com	\N	2014-11-19 15:54:21.924611	2014-11-19 15:54:51.795247	USD	172.16.128.2	1	0.00	0.00	0.00	spree	0.00	1	\N	\N	t	f	7RrujYcbC0do1bI92-o20w	0
\.


--
-- Name: spree_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_orders_id_seq', 9, true);


--
-- Data for Name: spree_orders_promotions; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_orders_promotions (order_id, promotion_id) FROM stdin;
\.


--
-- Data for Name: spree_payment_capture_events; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_payment_capture_events (id, amount, payment_id, created_at, updated_at) FROM stdin;
1	0.00	2	2014-11-13 18:11:52.756913	2014-11-13 18:11:52.756913
2	2.99	3	2014-11-14 16:07:55.865408	2014-11-14 16:07:55.865408
3	399.00	4	2014-11-18 15:56:34.349791	2014-11-18 15:56:34.349791
\.


--
-- Name: spree_payment_capture_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_payment_capture_events_id_seq', 3, true);


--
-- Data for Name: spree_payment_methods; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_payment_methods (id, type, name, description, active, environment, deleted_at, created_at, updated_at, display_on, auto_capture, preferences) FROM stdin;
1	Spree::PaymentMethod::Check	Pay by Check	Temp for testing	t	development	\N	2014-11-13 17:26:14.3163	2014-11-13 17:26:14.3163		\N	--- {}\n
\.


--
-- Name: spree_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_payment_methods_id_seq', 1, true);


--
-- Data for Name: spree_payments; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_payments (id, amount, order_id, source_id, source_type, payment_method_id, state, response_code, avs_response, created_at, updated_at, identifier, cvv_response_code, cvv_response_message) FROM stdin;
3	2.99	4	\N	\N	1	completed	\N	\N	2014-11-14 16:06:35.009211	2014-11-14 16:07:55.973262	FSTT3E7A	\N	\N
4	399.00	5	\N	\N	1	completed	\N	\N	2014-11-18 15:40:30.603089	2014-11-18 15:56:34.45148	ZAS98JQH	\N	\N
5	2.99	6	\N	\N	1	checkout	\N	\N	2014-11-19 14:35:47.32294	2014-11-19 14:35:47.32294	KN9TJQRU	\N	\N
\.


--
-- Name: spree_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_payments_id_seq', 5, true);


--
-- Data for Name: spree_preferences; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_preferences (id, value, key, created_at, updated_at) FROM stdin;
2	--- '2014-10-14T15:10:26-04:00'\n	spree/app_configuration/last_check_for_spree_alerts	2014-05-29 19:35:11.078647	2014-10-14 19:10:26.186331
3	--- 49\n...\n	spree/app_configuration/default_country_id	2014-05-29 20:20:15.717008	2014-05-29 20:20:15.717008
4	--- OSIF Software Store\n...\n	spree/app_configuration/site_name	2014-05-29 20:43:45.039053	2014-05-29 20:43:45.039053
5	--- ''\n	spree/app_configuration/default_seo_title	2014-05-29 20:43:45.048609	2014-05-29 20:43:45.048609
6	--- spree, demo\n...\n	spree/app_configuration/default_meta_keywords	2014-05-29 20:43:45.055367	2014-05-29 20:43:45.055367
7	--- Spree demo site\n...\n	spree/app_configuration/default_meta_description	2014-05-29 20:43:45.062307	2014-05-29 20:43:45.062307
8	--- demo.spreecommerce.com\n...\n	spree/app_configuration/site_url	2014-05-29 20:43:45.069156	2014-05-29 20:43:45.069156
1	--- false\n...\n	spree/app_configuration/allow_ssl_in_production	2014-05-29 19:35:07.560549	2014-11-19 19:52:04.369784
18	--- no-reply@buckeyevault.com\n...\n	spree/app_configuration/mails_from	2014-11-19 15:53:33.14047	2014-11-19 19:52:04.388752
9	--- false\n...\n	spree/app_configuration/allow_ssl_in_staging	2014-05-29 20:43:45.143015	2014-11-18 15:49:15.887356
10	--- false\n...\n	spree/app_configuration/allow_ssl_in_development_and_test	2014-05-29 20:43:45.149198	2014-11-18 15:49:15.892864
11	--- true\n...\n	spree/app_configuration/check_for_spree_alerts	2014-05-29 20:43:45.155017	2014-11-18 15:49:15.898536
12	--- false\n...\n	spree/app_configuration/display_currency	2014-05-29 20:43:45.160735	2014-11-18 15:49:15.904735
13	--- false\n...\n	spree/app_configuration/hide_cents	2014-05-29 20:43:45.166708	2014-11-18 15:49:15.911064
14	--- USD\n...\n	spree/app_configuration/currency	2014-05-29 20:43:45.172275	2014-11-18 15:49:15.916897
15	--- before\n...\n	spree/app_configuration/currency_symbol_position	2014-05-29 20:43:45.177805	2014-11-18 15:49:15.922999
16	--- "."\n	spree/app_configuration/currency_decimal_mark	2014-05-29 20:43:45.184156	2014-11-18 15:49:15.928339
17	--- ","\n	spree/app_configuration/currency_thousands_separator	2014-05-29 20:43:45.189759	2014-11-18 15:49:15.934468
\.


--
-- Name: spree_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_preferences_id_seq', 18, true);


--
-- Data for Name: spree_prices; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_prices (id, variant_id, amount, currency, deleted_at) FROM stdin;
1	1	20.00	USD	2014-07-22 14:39:22.355364
2	2	50.00	USD	2014-07-22 14:35:47.399069
3	3	75.00	USD	2014-07-22 14:38:45.989505
4	4	100.00	USD	2014-07-22 14:35:39.499716
5	5	50.00	USD	2014-07-22 14:36:01.400104
6	6	0.00	USD	\N
7	7	1.99	USD	\N
8	8	0.00	USD	\N
9	9	0.00	USD	\N
10	10	0.00	USD	\N
11	11	0.00	USD	\N
12	12	0.00	USD	\N
13	13	0.00	USD	\N
14	14	0.00	USD	\N
15	15	2.99	USD	\N
16	16	0.00	USD	\N
17	17	250.00	USD	\N
18	18	0.00	USD	\N
19	19	0.00	USD	\N
20	20	0.00	USD	\N
21	21	1500.00	USD	\N
22	22	0.00	USD	\N
23	23	0.00	USD	\N
24	24	199.00	USD	\N
25	25	3.99	USD	\N
26	26	0.00	USD	\N
27	27	250.00	USD	2014-07-22 18:52:26.863564
28	28	3000.00	USD	\N
29	29	399.00	USD	\N
30	30	40.00	USD	2014-07-22 14:46:33.779923
\.


--
-- Name: spree_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_prices_id_seq', 1, false);


--
-- Data for Name: spree_product_option_types; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_product_option_types (id, "position", product_id, option_type_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_product_option_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_product_option_types_id_seq', 1, false);


--
-- Data for Name: spree_product_properties; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_product_properties (id, value, product_id, property_id, created_at, updated_at, "position") FROM stdin;
\.


--
-- Name: spree_product_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_product_properties_id_seq', 1, false);


--
-- Data for Name: spree_products; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_products (id, name, description, available_on, deleted_at, slug, meta_description, meta_keywords, tax_category_id, shipping_category_id, created_at, updated_at, license_id, marketing_page, external_title, external_url, apple_itunes_url, google_play_url) FROM stdin;
1	OSU Branding Resources		2014-05-30 00:00:00	2014-07-22 14:39:22.387551	osu-branding-resources			\N	2	2014-05-30 13:58:10.028224	2014-07-22 14:39:22.387551	1	f				
2	Famous Mobile Starter Kit		2014-05-28 00:00:00	2014-07-22 14:35:47.437907	famous-mobile-starter-kit			1	2	2014-05-30 14:00:57.038024	2014-07-22 14:35:47.437907	1	f				
27	XL-Tool Scheduling Application 	"The software allows users to calculate duration of infusion appointments based on treatment selected, rearrange \npatient appointments within treatment spaces, quickly view and interpret clinic schedules and query data from the \ndatabase both for operational and analytical purposes. \n"	2014-07-21 00:00:00	2014-07-22 18:52:26.899045	xl-tool-scheduling-application		medical, facility, operations, logistics	\N	2	2014-07-21 17:35:44.370977	2014-07-22 18:52:26.899045	1	f				
30	Simple Archive Format Packager	Application makes it easy to prepare batch loads to ingest large amounts of materials into DSpace. In our case, it \nallows a librarian to fill out a spreadsheet with metadata for digital objects, we then run the Simple Archive \nFormat Packager over that data, and the resulting file structure is ready to import into DSpace. Manual \nsubmission to DSpace takes about 10 minutes per submission, where as this SAFPackager could process \nthousands of items in a minute. \n	\N	2014-07-22 14:46:33.816392	simple-archive-format-packager		libraries	\N	2	2014-07-21 17:38:32.699002	2014-07-22 14:46:33.816392	1	f				
3	Native Client SDK		2014-05-30 00:00:00	2014-07-22 14:38:46.021536	native-client-sdk			1	2	2014-05-30 20:17:50.396086	2014-07-22 14:38:46.021536	1	f				
4	Codiqa Desktop IDE		2014-05-30 00:00:00	2014-07-22 14:35:39.533855	codiqa-desktop-ide			1	2	2014-05-30 20:19:51.949952	2014-07-22 14:35:39.533855	1	f				
5	Framer Mobile Prototyping Plugin		2014-05-30 00:00:00	2014-07-22 14:36:01.438386	framer-mobile-prototyping-plugin			1	2	2014-05-30 20:24:30.116746	2014-07-22 14:36:01.438386	1	f				
7	OSU OB US	The app provides guidelines for obtaining point of care ultrasound images for obstetric applications.\n\nIOS\nhttps://itunes.apple.com/us/app/ob-us/id726122279?mt=8	2014-07-21 00:00:00	\N	ob-us			\N	2	2014-07-18 17:49:25.836112	2014-07-22 18:22:09.210504	1	f				
8	POC Ultrasound Guide	The Ohio State ultrasound app, POC U/S, is a guide to obtaining high quality ultrasounds of patients at the Point Of Care. It is intended to guide medical students, ultrasonography students, medical residents and physicians through the steps for obtaining each view within seven categories of point of care ultrasonography. The app also indicates the correct probe to use and gives tips for obtaining high quality images. Where appropriate the app provides information for calculating various clinical parameters.	2014-07-21 00:00:00	\N	poc-ultrasound-guide			\N	2	2014-07-21 14:32:16.122126	2014-07-22 18:48:10.287193	1	f				
9	InPromptu	inPromptu helps people of all ages learn new skills by watching video clips of others doing the skill. The person watches a series of video clips, each of which shows a part of the skill. By watching each clip, a person can learn even fairly complex skills quickly. As users learn the skill, they can choose how many clips to watch together, or they can watch the video of the entire skill. New skills are being added all the time.	2014-07-21 00:00:00	\N	inpromptu			\N	2	2014-07-21 14:37:18.95924	2014-07-22 18:02:24.435223	1	f				
10	P4 Challenge	Ohio State’s Wexner Medical Center native iOS app encourages users to play the P4 Challenge. This interactive game is designed to help you improve your health and well-being through a series of daily challenges. Each challenge is designed with P4 health in mind – a healthy lifestyle that is Predictive, Preventive, Personalized and Participatory.\n\n• Daily challenges are designed to motivate users to improve your health.\n• Completed challenges are awarded points that can be redeemed toward rewards.\n• Features like remind me later, or shuffe challenge allow users to personalize the game to meet their current health\nneeds.\n• Social share option lets users share accomplishments with friends via Facebook or Twitter.\n• Players can team up to earn additional points. Teams are made up of 4 or 8 people who participate in monthly\nchallenges.\n• Leaderboards allow players an opportunity to track personal progress as well as that of friends and teammates.	2014-07-21 00:00:00	\N	p4-challenge			\N	2	2014-07-21 14:41:09.856355	2014-07-22 18:48:23.296535	1	f				
11	RUOK: OSU	RUOK: OSU displays the number for the 24 hour/365 day suicide prevention crisis lines geographically closest to the caller's physical location. At the moment, service is only available for crisis centers in the state of Ohio. This app also provides the national Lifeline number and additional resources and suicide prevention information.\n\nhttps://play.google.com/store/apps/details?id=com.phonegap.OSUReach\n\nhttps://itunes.apple.com/us/app/ruok-osu/id577089492?mt=8	2014-07-21 00:00:00	\N	ruok-osu			\N	2	2014-07-21 14:53:54.208458	2014-07-22 18:55:10.907492	1	f				
12	CleanerU	Review and share feedback to make your campus cleaner for everyone. \n\nThe free app, CleanerU, was developed by a faculty member of OSU’s College of Public Health. It gives users the option of choosing whether their campus is clean or “can be cleaner,” then uploading a photo and noting whether there is an active smoker in the area, as well as what kind of litter is around. The location of where the picture was taken is automatically attached and placed on a map all users can browse.\n\n<img style="-webkit-user-select: none; cursor: -webkit-zoom-in;" src="http://thelantern.com/wp-content/uploads/2014/02/campus_app.jpg" width="269" height="388">\n\nDownload the app on the Apple itunes App Store\n<a href="https://itunes.apple.com/us/app/cleaneru/id726122308?mt=8" target=new>HERE</a>\n\nhttps://play.google.com/store/apps/details?id=edu.osu.cleaneru	2014-07-21 00:00:00	\N	cleaneru			\N	2	2014-07-21 15:02:45.944844	2014-07-22 18:55:48.8271	1	f				
13	MoCK Test	Presentamos MoCK Test: la aplicación móvil para estudiar y probar tus conocimientos en medicina. Cargada con más de 800 preguntas clínicas en español, es la mejor solución para el estudiante de medicina. Permite al usuario rápidamente elegir una categoría clínica y comenzar a responder preguntas en una interfaz sencilla y rápida. Feedback inmediato para cada pregunta y estadísticas globales sobre la performance indican al estudiante sus áreas más débiles, orientándolo en su estudio. MoCK Test requiere llenar un breve registro solicitando información sobre país, universidad y ano de egreso de estudios médicos. La versión 1.0 está orientada a preparar a estudiantes de medicina para el examen único nacional de conocimientos en medicina (EUNACOM). MoCK Test se reserva el derecho de registrar en forma anónima estadísticas de uso de los usuarios. MoCK Test requiere conexión a internet.\n\nios\nhttps://itunes.apple.com/us/app/mock-test/id535847104?mt=8\n\ndroid\nhttps://play.google.com/store/apps/details?id=edu.osumc.bmi.mock	2014-07-21 00:00:00	\N	mock-test			\N	2	2014-07-21 15:32:15.939834	2014-07-22 18:07:42.800855	1	f				
29	Facility Level of Service Charge Calculator	This charging/billing methodology was designed to create facility level of service charge automatically based upon nursing care documented during a patient visit to the Emergency Department. The current audience of users are emergency department nurses. \n\nIn today's tight reimbursement regulations climate, better tools to address the complex rule sets can make it difficult for hospital administrators to achieve a compliant and consistent charging strategy across services.  \n\nThis is methodology, excel spreadsheet only.\n\n	2014-07-21 00:00:00	\N	facility-level-of-service-charge-calculator		medical, facility, operations, logistics	\N	2	2014-07-21 17:37:43.882562	2014-07-22 18:56:39.444981	1	f				
28	StudySearch	Researchers at The Ohio State University led by Dr. Carson Reider and Tara Payne have developed a web-based application for searching a comprehensive and layperson friendly listing of research studies that are approved for the recruitment of study subjects. Postings occur in one of two ways: 1) Studies registered on ClinicalTrials.gov are automatically downloaded at the beginning of each month; or 2) Researchers can submit studies directly to be posted on the website.  Studies are annotated with MeSH keywords associated with the related medical condition and/or study intervention; these keywords, in addition to age group and gender, can then used to search by the general public. Each study listed is updated yearly based upon the IRB annual approval date, or can be removed based upon study recruitment status.\n\nWeb-accessible lay-friendly listing of IRB-approved protocols that are accruing study subjects. Supports regulatory iterative review and approval of public study listings	\N	\N	studysearch		medical, search, tool, analytics	\N	2	2014-07-21 17:36:54.039982	2014-07-22 18:58:01.713892	1	f				
14	Hymenoptera Online (HOL)	The Hymenoptera Online (HOL) mobile app from the C.A.Triplehorn Insect Collection (Ohio State University) brings the usefulness of the popular web resource to your iOS device. Designed for taxonomists, field collectors and bug enthusiasts, the HOL app provides information on taxa primarily within the insect order of Hymenoptera (ants, wasps, bees) but also in other insect orders such as Hemiptera (true bugs, leafhoppers, cicadas), Coleoptera (beetles), and Diptera (flies). Also available is an extensive array of taxonomic information on Acari (mites, ticks) from the Ohio State Acarology Lab and many more animal groups already added.\n\nNeed to find an article about a fire ant (Solenopsis) that was recently described while you were visiting a collection? Open up the HOL app, search for "Solenopsis", get a list of all the articles that deal with this genus, and view the article right from your iPhone or iPad. You may even save the article to your local HOL library to read the original description of the new species on a flight when you do not have WiFi or cellular access. The enthusiast may also save an article that contains a key to the species of fire ants to provide a real-time identification. With almost 7,000 publications available for download, the paper you're looking for may be at the palm of your hands.\n\nLooking to catch the American pelecinid wasp (Pelecinus polyturator) on "the Cape" in Massachusetts? Use the mapping capabilities on the HOL app to find the distribution of the species, then click on a distribution point to get the locality information. Also, get driving directions to the collecting locality with just a press of your finger by using your current location, the coordinates of the locale, and the Google Maps/Apple Maps app. The app can also find collecting localities near where you stand.\n\nThe HOL mobile app also provides access to over 10,000 high resolution specimen images with an interface that mimics the useful and comfortable iOS Photos app. Want to see images of the recently revised scelionid wasp genus Heptascelio? Peruse the images in thumbnails view, or click in image for a full resolution investigation zooming in and on the image with intuitive simplicity.\n\nVisit the full web version of Hymenoptera Online @ http://hol.osu.edu	2014-07-21 00:00:00	\N	hymenoptera-online-hol			\N	2	2014-07-21 16:48:38.495951	2014-07-22 18:00:19.632231	1	f				
16	Expand Your World	The "Expand Your World" app lets students and other OSU stakeholders have a cultural, demographic, economic and linguistic background of the 31 languages taught at Ohio State. It contains a short intro video, a quiz and 25 practice audio phrases.\n\nhttps://itunes.apple.com/us/app/expand-your-world/id633593140?mt=8\n\nhttps://play.google.com/store/apps/details?id=air.edu.osu.flc.expandyourworld	2014-07-21 00:00:00	\N	expand-your-world			\N	2	2014-07-21 16:51:22.35927	2014-07-22 18:54:24.978135	1	f				
17	Customer Facing Kiosk	"This kiosk is used to interface with customers and provide feedback based on the selections that they choose. It has the ability to interface with system hardware as well as various web technologies.\n\nUseful in IT related fields where interfacing with specific systems (Such as Service-Now) is a requirement."	2014-07-21 00:00:00	\N	customer-facing-kiosk		kiosk, facility, logistics	\N	2	2014-07-21 17:07:28.088803	2014-07-22 17:46:02.444115	1	f				
18	Get It Right	Cancer Screening Application\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ullamcorper, orci eget scelerisque venenatis, metus nunc sollicitudin orci, et luctus erat dolor et leo. Curabitur eget sagittis risus. Fusce sit amet egestas urna, non suscipit magna. Vestibulum tempor urna mauris, ac fringilla risus pulvinar at. Integer vel metus odio. Nam a euismod justo, id viverra massa. Maecenas hendrerit quam et elit sagittis viverra. Praesent at lorem arcu. Vivamus vitae consectetur arcu. Etiam tempor tellus in mollis facilisis. Integer in eros quis massa luctus tempus non nec urna. In placerat dui eget mattis imperdiet. Cras tempus turpis vel urna rutrum, eget tempus mauris posuere. Nulla egestas hendrerit mi, id ultricies nunc pellentesque vel.\n\nDuis bibendum libero tortor, sit amet pulvinar neque malesuada a. Cras sit amet tellus nec odio elementum venenatis. Pellentesque ut vulputate urna. Aliquam tincidunt enim nec sem placerat placerat. Donec molestie ante a euismod cursus. Mauris ultricies, odio vel iaculis vulputate, justo dui pulvinar felis, euismod malesuada sem sapien vel magna. Cras justo sapien, varius hendrerit nisl a, semper ullamcorper turpis. Maecenas malesuada mauris id sagittis blandit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec tempor faucibus nunc.	2014-07-21 00:00:00	\N	get-it-right		medical, education	\N	2	2014-07-21 17:10:07.610073	2014-07-22 17:56:09.934109	1	f				
19	Waiting Room Information System 	The Waiting Room Information System is a website designed to give patients up to the minute in details regarding wait times for the linear accelerators and physicians who are in the clinic.\n\nOur system allows for direct access and up to the minute display of wait times for physicians as well as the treatment machines available in radiation oncology rather than just transmission to a patient. It also wlll not allow patients to schedule appoints. The data entry also allows for input of cause of the delay and therefore statistics can be analyzed and processes can be adjusted. The statistics being stored and the feedback mechanism provided for improved efficiency is the largest difference.\n\nAny hospital department with need to display physician or equipment wait times and communicate to patients the\ndifferent physicians in the clinic on different days can benefit from this software.	2014-07-21 00:00:00	\N	waiting-room-information-system		medical, facility, operations, logistics	\N	2	2014-07-21 17:10:58.683277	2014-07-22 18:58:20.470359	1	f				
20	Research Poster Day Application 	The Research/Poster Day application allows administrators and/or event coordinators with a means to easily disseminate information to participants and attendees of their poster or research event. It features tools for poster submissions, judge sign-ups, assignment of judges to posters, and scoring of posters. Auto-assignment of judges to posters by matching categories to specialty interests and available sessions (if event is multi-session) eases the organization of the event for administrators and the ability for judges to submit their scores in real-time via mobile device facilitates timely announcements of the event awardees.	2014-07-21 00:00:00	\N	research-poster-day-application		education, facility, event management	\N	2	2014-07-21 17:12:29.851823	2014-07-22 18:57:49.179604	1	f				
21	Ohio 4-H Project Central Wordpress Theme	"Ohio 4-H Project Central is an online database that provides descriptions and ratings of Ohio 4-H publications, including 4-H \nproject books. Descriptions are complemented by sample pages from each publication. Ratings and comments are solicitated \nand collected. The framework and software can be adapted to other publication collections.\n\nOhio 4-H Project Central makes it easy for members, project helpers, or anyone interested in purchasing Ohio 4-H curriculum \nproducts to find specific titles, browse titles by difficulty, or browse titles by topic area. Each detail page includes basic \npublication information, a product description, rating results to date, and links to a survey and eStore. \nProject Central makes it easier for 4-H members to make informed decisions about project selection. In-depth views of \npublications and customer opinions of them have been avaialble only at the very local level, where members and project \nhelpers look at the actual print materials and talk to their friends in small group settings. Project selection is sometimes \ndifficult--4-H members and their families have to select at least one project each year from a large collection of offerings. \nOhio 4-H Project Central makes project selection easier with convenient access to a friendly, one-stop website that looks as \ngood on a mobile phone as it does on a desktop. \nIn addition to the Ohio 4-H audience, Project Central will reach 4-H members around the country, many of whom are not \ndirectly aware of the titles offered by Ohio."	2014-07-21 00:00:00	\N	ohio-4-h-project-central-wordpress-theme		ag, 4h, education	\N	2	2014-07-21 17:15:54.803641	2014-07-22 18:57:32.820898	1	f				
22	Interactive Health Calculator and Visualization Module (SPHERE) 	"Patient-provider communication is critical for educating patients and for modifying patient behavior. The software is designed \nto enhance the communication process between patients via a health score visualization tool. The tool can be personalized \nwith validated health scoring algorithms for health promotion and disease prevention and management. \n\nThe purpose of this software is to deliver a health score visualization via electronic medical record and to ameliorate barriers \nto patient-provider communication of disease prevention and management, since providers can modify patient behavior with a \nsuccessful communication strategy. The software is scalable to score calculation modules for different diseases and provider \nspecialties. The tool has an interactive component that allows the patient to set behavior change goals and immediately \nassess the impact of these changes on the health score. \nThe electronic medical record is not designed to improve patient-provider communication, nor for the visualization of health \npromoting data. We developed an individualized, automated health score visualization tool that is tethered to the electronic \nmed""1cal record. Health care providers routinely use risk scores as decision support tools and to assess patient health. \nDeliberations regarding health care decision making are often not shared with patients, hindering patients' ability to fully \nunderstand their own risks and evaluate the benefits and drawbacks of behavior change. The software provides substantial \nextant infrastructure for increasing patient-provider communication and improving patients' health as well as informed \ndecision-making. In addition, the one-page application allows for real-time data input and score calculation, thus avoiding \nnavigating away and re-submitting data elements. \nThe primary audiences are the informed, activated patient and their prepared, proactive care providers. We believe the \ntargeted patients, as well as future patients of the targeted health care providers, will directly benefit from this intervention in \nterms of improved health, and the prevention and treatment of modifiable lifestyle behaviors. \n"	2014-07-21 00:00:00	\N	interactive-health-calculator-and-visualization-module-sphere		medical, patient engagement	\N	2	2014-07-21 17:19:23.210759	2014-07-22 18:56:57.567202	1	f				
23	Livestock Growth Tracker	The Ohio 4-H Livestock Growth Tracker mobile app is a convenient way for 4-H members, FFA members, and  anyone raising a livestock animal (beef, sheep, swine, and goats) to monitor its growth. The metric, called average daily gain (ADG) is an important indicator because it reveals information about animal health, efficiency of operations, profitability, etc. A related metric called feed efficiency further refines measurement of these factors. \n	2014-07-21 00:00:00	\N	livestock-growth-tracker		ag, 4h, education	\N	2	2014-07-21 17:20:17.757342	2014-07-22 18:04:30.960076	1	f				
24	XiMeRa: a LaTeX to eBook Conversion Process 	"This software facilitates the authoring of interactive eBooks. \n \nThere are separate components: The content conversion tool (converts LaTeX markup to a proprietary format), a content navigator for reading documents (in the proprietary format), a JavaScript library of interactive elements (that can be easily used with our format and Content Navigator). \n\nOur product differs from PDFs and ePub by allowing interactive elements. \nIt differs from iBooks Author and ePub by allowing sophisticated typesetting. \nIt differs from iBooks Author by being platform independent. \nIt differs from all by allowing detailed analytics, being based on LaTeX, and learning management system \nintegeration. \n"	2014-07-21 00:00:00	\N	ximera-a-latex-to-ebook-conversion-process		education, publishing, research	\N	2	2014-07-21 17:31:56.727307	2014-07-22 18:58:32.934033	1	f				
25	Total Horse	Live the dream of owning and looking after a realistic horse, and share the experience with your friends! \n\nHORSE CARE \nCare for your horse by grooming, feeding and treating it. Build a bond together in a wide range of interactive 3D activities. And, when you’re ready, there are eight different breeds to collect and look after! \n\nCOMPETITIONS \nExciting show jumping events are waiting for you! Practice makes perfect as you train to compete in a series of challenging competitions. Keeping your horse happy and healthy is the key to success! Will you reach the World Championships? \n\nAWESOME IN-GAME CAMERA \nTake pictures of your horse in action as it plays and eats in the paddock – it’s as if you’re really there! \n\nSOCIAL GAMEPLAY \nHelp each other out: visit your friends' stables to look after their horses – many hands make light work! \n\nAMAZING GRAPHICS \nMy Horse looks amazing. Watch how your horse moves and how its ears tell you its mood. Marvel at the Pinto horses – each one looking unique. Or soak up the atmosphere during a prestigious show jumping competition. My Horse brings you into a world that you won’t want to leave. \n\nDownload My Horse now to look after your very own horse! \n\nMake sure you play online in order to get access to the latest content and features, as well as ensuring that your profile is saved should anything happen to your device.\n\nPLEASE NOTE! My Horse is free to play, but it contains items that can be purchased for real money. You can toggle these purchases on/off in the "Restrictions" menu on your device.\n	2014-07-21 00:00:00	\N	total-horse		ag, 4h, education	\N	2	2014-07-21 17:33:43.244358	2014-07-22 18:51:33.443	1	f				
26	Nutrient Analysis Conversion to Diet Quality Index 	Sarah programmed into Excel the calculations to take the output of nutrient analysis software (Le. nutrient \namounts consumed and food consumed) and create the calculation and automation of a quality index tool (called \nAHEI) with associated color coding. The requirementsfor the various aspects of the AHEI index tool are available \nby reading the literature. (AHEI =Alternative Healthy Eating Index). \n\nThis allows us to view and automate a diet's quality. These quality index tools are described in the literature but \nare not available electronically. We took dietary data (Le. output of what people said they ate, we analyzed it \nusing the usual nutrient analysis software that we have and we used the exported text file data of nutrients \nconsumed and food consumed to calculate an index per food category. All done according to the literature \ndescription of that index tool). We used data from various studies here at the OSU CRC Bionutrition Core and \nare able to convert it to an overall index. This is most succinctly described by the question .... 'is that a good diet \nor a bad diet?' \n	2014-07-21 00:00:00	\N	nutrient-analysis-conversion-to-diet-quality-index		nutrition, food, education, research	\N	2	2014-07-21 17:34:38.05119	2014-07-22 18:57:17.539253	1	f				
6	Buckeye Stroll	Take a walk through Ohio State University history using Buckeye Stroll, a location-aware mobile application developed by the OSU Libraries. Buckeye Stroll features a map view of more than 60 sites of interest on The Ohio State University campus, and a browse view for locating a known site by name. Each stop on the tour includes several historical photographs from the OSU Photo Archives, featuring highlights of the University’s history.\r\n\r\n\r\n\r\n	2014-06-02 00:00:00	\N	buckeye-stroll			1	2	2014-06-03 13:19:53.014046	2014-11-13 15:55:05.053928	1	f			https://itunes.apple.com/us/app/buckeye-stroll/id491703629?mt=8	https://play.google.com/store/apps/details?id=edu.osu.buckeyestroll
15	Good Bugs +	A detailed reference and pictorial guide to help farmers, gardeners, and naturalists recognize and identify bee pollinators, insects and spiders (natural enemies) that can reduce pest populations, and select native plants that attract and provide a food source (nectar and pollen) to natural enemies and pollinators.\r\n\r\nios\r\nhttps://itunes.apple.com/us/app/good-bugs-+/id674667321?mt=8\r\n\r\n	2014-07-21 00:00:00	\N	good-bugs			1	2	2014-07-21 16:50:15.756737	2014-11-14 15:47:24.213029	1	f				
\.


--
-- Name: spree_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_products_id_seq', 1, false);


--
-- Data for Name: spree_products_promotion_rules; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_products_promotion_rules (product_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: spree_products_taxons; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_products_taxons (product_id, taxon_id, id, "position") FROM stdin;
6	2	10	10
6	1	11	11
17	7	12	12
18	1	13	13
19	7	14	14
20	7	15	15
22	7	16	16
23	1	17	17
24	7	18	18
25	1	19	19
26	4	20	20
28	7	21	21
29	4	22	22
12	2	24	23
12	1	25	24
16	1	26	25
16	2	27	26
18	2	28	27
15	1	29	28
15	2	30	29
14	1	31	30
14	2	32	31
9	1	33	32
9	2	34	33
23	2	35	34
13	1	36	35
13	2	37	36
13	3	38	37
26	7	39	38
7	1	40	39
7	2	41	40
21	7	42	41
10	1	43	42
10	2	44	43
8	1	45	44
8	2	46	45
11	1	47	46
11	2	48	47
25	2	49	48
6	3	50	49
16	3	51	50
11	3	52	51
12	3	53	52
29	9	54	53
22	9	55	54
22	8	56	55
26	8	57	56
21	8	58	57
20	8	59	58
28	8	60	59
19	8	61	60
24	8	62	61
\.


--
-- Name: spree_products_taxons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_products_taxons_id_seq', 1, false);


--
-- Data for Name: spree_promotion_action_line_items; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_promotion_action_line_items (id, promotion_action_id, variant_id, quantity) FROM stdin;
\.


--
-- Name: spree_promotion_action_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_promotion_action_line_items_id_seq', 1, false);


--
-- Data for Name: spree_promotion_actions; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_promotion_actions (id, promotion_id, "position", type, deleted_at) FROM stdin;
\.


--
-- Name: spree_promotion_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_promotion_actions_id_seq', 1, false);


--
-- Data for Name: spree_promotion_rules; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_promotion_rules (id, promotion_id, user_id, product_group_id, type, created_at, updated_at, code, preferences) FROM stdin;
\.


--
-- Name: spree_promotion_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_promotion_rules_id_seq', 1, false);


--
-- Data for Name: spree_promotion_rules_users; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_promotion_rules_users (user_id, promotion_rule_id) FROM stdin;
\.


--
-- Data for Name: spree_promotions; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_promotions (id, description, expires_at, starts_at, name, type, usage_limit, match_policy, code, advertise, path, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_promotions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_promotions_id_seq', 1, false);


--
-- Data for Name: spree_properties; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_properties (id, name, presentation, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_properties_id_seq', 1, false);


--
-- Data for Name: spree_properties_prototypes; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_properties_prototypes (prototype_id, property_id) FROM stdin;
\.


--
-- Data for Name: spree_prototypes; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_prototypes (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_prototypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_prototypes_id_seq', 1, false);


--
-- Data for Name: spree_return_authorizations; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_return_authorizations (id, number, state, amount, order_id, reason, created_at, updated_at, stock_location_id) FROM stdin;
\.


--
-- Name: spree_return_authorizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_return_authorizations_id_seq', 1, false);


--
-- Data for Name: spree_roles; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_roles (id, name) FROM stdin;
1	admin
2	user
\.


--
-- Name: spree_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_roles_id_seq', 1, false);


--
-- Data for Name: spree_roles_users; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_roles_users (role_id, user_id) FROM stdin;
1	2
1	3
1	4
\.


--
-- Data for Name: spree_shipments; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipments (id, tracking, number, cost, shipped_at, order_id, address_id, state, created_at, updated_at, stock_location_id, adjustment_total, additional_tax_total, promo_total, included_tax_total, pre_tax_amount) FROM stdin;
\.


--
-- Name: spree_shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_shipments_id_seq', 7, true);


--
-- Data for Name: spree_shipping_categories; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipping_categories (id, name, created_at, updated_at) FROM stdin;
1	Default	2014-05-29 19:33:39.046982	2014-05-29 19:33:39.046982
2	Digital	2014-05-30 13:56:07.980199	2014-05-30 13:56:07.980199
\.


--
-- Name: spree_shipping_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_shipping_categories_id_seq', 1, false);


--
-- Data for Name: spree_shipping_method_categories; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipping_method_categories (id, shipping_method_id, shipping_category_id, created_at, updated_at) FROM stdin;
1	1	2	2014-05-30 13:57:17.486678	2014-05-30 13:57:17.486678
\.


--
-- Name: spree_shipping_method_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_shipping_method_categories_id_seq', 1, false);


--
-- Data for Name: spree_shipping_methods; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipping_methods (id, name, display_on, deleted_at, created_at, updated_at, tracking_url, admin_name, tax_category_id) FROM stdin;
1	Digital		\N	2014-05-30 13:57:17.481684	2014-05-30 13:57:17.481684		digital	1
\.


--
-- Name: spree_shipping_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_shipping_methods_id_seq', 1, false);


--
-- Data for Name: spree_shipping_methods_zones; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipping_methods_zones (shipping_method_id, zone_id) FROM stdin;
1	1
1	2
\.


--
-- Data for Name: spree_shipping_rates; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_shipping_rates (id, shipment_id, shipping_method_id, selected, cost, created_at, updated_at, tax_rate_id) FROM stdin;
\.


--
-- Name: spree_shipping_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_shipping_rates_id_seq', 1, false);


--
-- Data for Name: spree_skrill_transactions; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_skrill_transactions (id, email, amount, currency, transaction_id, customer_id, payment_type, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_skrill_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_skrill_transactions_id_seq', 1, false);


--
-- Data for Name: spree_state_changes; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_state_changes (id, name, previous_state, stateful_id, user_id, stateful_type, next_state, created_at, updated_at) FROM stdin;
1	order	cart	1	4	Spree::Order	address	2014-07-18 17:47:05.627442	2014-07-18 17:47:05.627442
2	payment	checkout	2	\N	Spree::Payment	processing	2014-11-13 18:11:52.619196	2014-11-13 18:11:52.619196
3	payment	processing	2	\N	Spree::Payment	completed	2014-11-13 18:11:52.860739	2014-11-13 18:11:52.860739
4	order	cart	4	\N	Spree::Order	address	2014-11-14 15:42:15.268941	2014-11-14 15:42:15.268941
5	order	address	4	1	Spree::Order	payment	2014-11-14 16:05:37.618533	2014-11-14 16:05:37.618533
6	order	payment	4	1	Spree::Order	complete	2014-11-14 16:06:35.193375	2014-11-14 16:06:35.193375
7	payment	\N	4	1	Spree::Order	balance_due	2014-11-14 16:06:35.215229	2014-11-14 16:06:35.215229
8	payment	checkout	3	\N	Spree::Payment	processing	2014-11-14 16:07:55.744513	2014-11-14 16:07:55.744513
9	payment	balance_due	4	1	Spree::Order	paid	2014-11-14 16:07:55.992526	2014-11-14 16:07:55.992526
10	payment	processing	3	\N	Spree::Payment	completed	2014-11-14 16:07:55.998075	2014-11-14 16:07:55.998075
11	order	cart	5	1	Spree::Order	address	2014-11-18 15:26:49.318653	2014-11-18 15:26:49.318653
12	order	address	5	1	Spree::Order	payment	2014-11-18 15:40:17.518832	2014-11-18 15:40:17.518832
13	order	payment	5	1	Spree::Order	complete	2014-11-18 15:40:30.750032	2014-11-18 15:40:30.750032
14	payment	\N	5	1	Spree::Order	balance_due	2014-11-18 15:40:30.76946	2014-11-18 15:40:30.76946
15	payment	checkout	4	\N	Spree::Payment	processing	2014-11-18 15:56:34.275088	2014-11-18 15:56:34.275088
16	payment	balance_due	5	1	Spree::Order	paid	2014-11-18 15:56:34.466672	2014-11-18 15:56:34.466672
17	payment	processing	4	\N	Spree::Payment	completed	2014-11-18 15:56:34.472199	2014-11-18 15:56:34.472199
18	order	cart	6	1	Spree::Order	address	2014-11-19 14:34:09.512257	2014-11-19 14:34:09.512257
19	order	address	6	1	Spree::Order	payment	2014-11-19 14:35:35.559219	2014-11-19 14:35:35.559219
20	order	payment	6	1	Spree::Order	complete	2014-11-19 14:35:47.503605	2014-11-19 14:35:47.503605
21	payment	\N	6	1	Spree::Order	balance_due	2014-11-19 14:35:47.525371	2014-11-19 14:35:47.525371
22	order	cart	7	1	Spree::Order	address	2014-11-19 15:03:20.096965	2014-11-19 15:03:20.096965
23	order	address	7	1	Spree::Order	complete	2014-11-19 15:03:30.947662	2014-11-19 15:03:30.947662
24	payment	\N	7	1	Spree::Order	paid	2014-11-19 15:03:30.959096	2014-11-19 15:03:30.959096
25	order	cart	8	1	Spree::Order	address	2014-11-19 15:05:04.724852	2014-11-19 15:05:04.724852
26	order	address	8	1	Spree::Order	complete	2014-11-19 15:05:14.32811	2014-11-19 15:05:14.32811
27	payment	\N	8	1	Spree::Order	paid	2014-11-19 15:05:14.339144	2014-11-19 15:05:14.339144
28	order	cart	9	1	Spree::Order	address	2014-11-19 15:54:27.989439	2014-11-19 15:54:27.989439
29	order	address	9	1	Spree::Order	complete	2014-11-19 15:54:51.77777	2014-11-19 15:54:51.77777
30	payment	\N	9	1	Spree::Order	paid	2014-11-19 15:54:51.786133	2014-11-19 15:54:51.786133
\.


--
-- Name: spree_state_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_state_changes_id_seq', 30, true);


--
-- Data for Name: spree_states; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_states (id, name, abbr, country_id, updated_at) FROM stdin;
1	Michigan	MI	49	2014-05-29 20:20:15.799892
2	South Dakota	SD	49	2014-05-29 20:20:15.805608
3	Washington	WA	49	2014-05-29 20:20:15.809717
4	Wisconsin	WI	49	2014-05-29 20:20:15.813843
5	Arizona	AZ	49	2014-05-29 20:20:15.817927
6	Illinois	IL	49	2014-05-29 20:20:15.822258
7	New Hampshire	NH	49	2014-05-29 20:20:15.826281
8	North Carolina	NC	49	2014-05-29 20:20:15.830378
9	Kansas	KS	49	2014-05-29 20:20:15.834441
10	Missouri	MO	49	2014-05-29 20:20:15.838504
11	Arkansas	AR	49	2014-05-29 20:20:15.842871
12	Nevada	NV	49	2014-05-29 20:20:15.84699
13	District of Columbia	DC	49	2014-05-29 20:20:15.850942
14	Idaho	ID	49	2014-05-29 20:20:15.854904
15	Nebraska	NE	49	2014-05-29 20:20:15.858841
16	Pennsylvania	PA	49	2014-05-29 20:20:15.86288
17	Hawaii	HI	49	2014-05-29 20:20:15.867242
18	Utah	UT	49	2014-05-29 20:20:15.871106
19	Vermont	VT	49	2014-05-29 20:20:15.875094
20	Delaware	DE	49	2014-05-29 20:20:15.879064
21	Rhode Island	RI	49	2014-05-29 20:20:15.883363
22	Oklahoma	OK	49	2014-05-29 20:20:15.887538
23	Louisiana	LA	49	2014-05-29 20:20:15.892566
24	Montana	MT	49	2014-05-29 20:20:15.89677
25	Tennessee	TN	49	2014-05-29 20:20:15.900835
26	Maryland	MD	49	2014-05-29 20:20:15.904675
27	Florida	FL	49	2014-05-29 20:20:15.908567
28	Virginia	VA	49	2014-05-29 20:20:15.912414
29	Minnesota	MN	49	2014-05-29 20:20:15.916313
30	New Jersey	NJ	49	2014-05-29 20:20:15.92018
31	Ohio	OH	49	2014-05-29 20:20:15.92406
32	California	CA	49	2014-05-29 20:20:15.927927
33	North Dakota	ND	49	2014-05-29 20:20:15.931825
34	Maine	ME	49	2014-05-29 20:20:15.935864
35	Indiana	IN	49	2014-05-29 20:20:15.939688
36	Texas	TX	49	2014-05-29 20:20:15.943589
37	Oregon	OR	49	2014-05-29 20:20:15.948456
38	Wyoming	WY	49	2014-05-29 20:20:15.95264
39	Alabama	AL	49	2014-05-29 20:20:15.95664
40	Iowa	IA	49	2014-05-29 20:20:15.960492
41	Mississippi	MS	49	2014-05-29 20:20:15.964436
42	Kentucky	KY	49	2014-05-29 20:20:15.968285
43	New Mexico	NM	49	2014-05-29 20:20:15.972126
44	Georgia	GA	49	2014-05-29 20:20:15.977547
45	Colorado	CO	49	2014-05-29 20:20:15.981463
46	Massachusetts	MA	49	2014-05-29 20:20:15.985349
47	Connecticut	CT	49	2014-05-29 20:20:15.989258
48	New York	NY	49	2014-05-29 20:20:15.993197
49	South Carolina	SC	49	2014-05-29 20:20:15.997767
50	Alaska	AK	49	2014-05-29 20:20:16.011932
51	West Virginia	WV	49	2014-05-29 20:20:16.025475
52	U.S. Armed Forces - Americas	AA	49	2014-05-29 20:20:16.029722
53	U.S. Armed Forces - Europe	AE	49	2014-05-29 20:20:16.034399
54	U.S. Armed Forces - Pacific	AP	49	2014-05-29 20:20:16.03841
\.


--
-- Name: spree_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_states_id_seq', 1, false);


--
-- Data for Name: spree_stock_items; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_stock_items (id, stock_location_id, variant_id, count_on_hand, created_at, updated_at, backorderable, deleted_at) FROM stdin;
1	1	1	0	2014-05-30 13:58:10.092836	2014-07-22 14:39:22.341476	t	2014-07-22 14:39:22.341476
2	1	2	0	2014-05-30 14:00:57.05421	2014-07-22 14:35:47.366484	t	2014-07-22 14:35:47.366484
3	1	3	0	2014-05-30 20:17:50.412399	2014-07-22 14:38:45.97629	t	2014-07-22 14:38:45.97629
4	1	4	0	2014-05-30 20:19:51.971301	2014-07-22 14:35:39.462643	t	2014-07-22 14:35:39.462643
5	1	5	0	2014-05-30 20:24:30.151515	2014-07-22 14:36:01.387492	t	2014-07-22 14:36:01.387492
6	1	6	0	2014-06-03 13:19:53.06248	2014-06-03 13:19:53.06248	t	\N
7	1	7	0	2014-07-18 17:49:25.875545	2014-07-18 17:49:25.875545	t	\N
8	1	8	0	2014-07-21 14:32:16.182795	2014-07-21 14:32:16.182795	t	\N
9	1	9	0	2014-07-21 14:37:18.974887	2014-07-21 14:37:18.974887	t	\N
10	1	10	0	2014-07-21 14:41:09.874287	2014-07-21 14:41:09.874287	t	\N
11	1	11	0	2014-07-21 14:53:54.22565	2014-07-21 14:53:54.22565	t	\N
12	1	12	0	2014-07-21 15:02:45.961628	2014-07-21 15:02:45.961628	t	\N
13	1	13	0	2014-07-21 15:32:15.958038	2014-07-21 15:32:15.958038	t	\N
14	1	14	0	2014-07-21 16:48:38.51221	2014-07-21 16:48:38.51221	t	\N
15	1	15	0	2014-07-21 16:50:15.772563	2014-07-21 16:50:15.772563	t	\N
16	1	16	0	2014-07-21 16:51:22.374715	2014-07-21 16:51:22.374715	t	\N
17	1	17	0	2014-07-21 17:07:28.105859	2014-07-21 17:07:28.105859	t	\N
18	1	18	0	2014-07-21 17:10:07.64719	2014-07-21 17:10:07.64719	t	\N
19	1	19	0	2014-07-21 17:10:58.698127	2014-07-21 17:10:58.698127	t	\N
20	1	20	0	2014-07-21 17:12:29.867605	2014-07-21 17:12:29.867605	t	\N
21	1	21	0	2014-07-21 17:15:54.824092	2014-07-21 17:15:54.824092	t	\N
22	1	22	0	2014-07-21 17:19:23.227156	2014-07-21 17:19:23.227156	t	\N
23	1	23	0	2014-07-21 17:20:17.77208	2014-07-21 17:20:17.77208	t	\N
24	1	24	0	2014-07-21 17:31:56.742995	2014-07-21 17:31:56.742995	t	\N
25	1	25	0	2014-07-21 17:33:43.259886	2014-07-21 17:33:43.259886	t	\N
26	1	26	0	2014-07-21 17:34:38.066081	2014-07-21 17:34:38.066081	t	\N
27	1	27	0	2014-07-21 17:35:44.387096	2014-07-22 18:52:26.849719	t	2014-07-22 18:52:26.849719
28	1	28	0	2014-07-21 17:36:54.055396	2014-07-21 17:36:54.055396	t	\N
29	1	29	0	2014-07-21 17:37:43.899238	2014-07-21 17:37:43.899238	t	\N
30	1	30	0	2014-07-21 17:38:32.71364	2014-07-22 14:46:33.76601	t	2014-07-22 14:46:33.76601
\.


--
-- Name: spree_stock_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_stock_items_id_seq', 1, false);


--
-- Data for Name: spree_stock_locations; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_stock_locations (id, name, created_at, updated_at, address1, address2, city, state_id, state_name, country_id, zipcode, phone, active, backorderable_default, propagate_all_variants, admin_name) FROM stdin;
1	default	2014-05-29 19:33:38.105837	2014-05-29 19:33:38.105837	\N	\N	\N	\N	\N	\N	\N	\N	t	t	t	\N
\.


--
-- Name: spree_stock_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_stock_locations_id_seq', 1, false);


--
-- Data for Name: spree_stock_movements; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_stock_movements (id, stock_item_id, quantity, action, created_at, updated_at, originator_id, originator_type) FROM stdin;
\.


--
-- Name: spree_stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_stock_movements_id_seq', 1, false);


--
-- Data for Name: spree_stock_transfers; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_stock_transfers (id, type, reference, source_location_id, destination_location_id, created_at, updated_at, number) FROM stdin;
\.


--
-- Name: spree_stock_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_stock_transfers_id_seq', 1, false);


--
-- Data for Name: spree_stores; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_stores (id, name, url, meta_description, meta_keywords, seo_title, mail_from_address, default_currency, code, "default", created_at, updated_at) FROM stdin;
1	Buckeye Vault	http://localhost:8888/osif-store/	Ohio State Innovation Foundation Software	Ohio State Innovation Foundation, software, Ohio State University		spree@example.com	USD	spree	t	2014-10-23 13:33:58.301943	2014-11-18 15:49:15.945236
\.


--
-- Name: spree_stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_stores_id_seq', 1, true);


--
-- Data for Name: spree_tax_categories; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_tax_categories (id, name, description, is_default, deleted_at, created_at, updated_at) FROM stdin;
1	Digital	digital products	f	\N	2014-05-30 13:55:49.872733	2014-05-30 13:55:49.872733
\.


--
-- Name: spree_tax_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_tax_categories_id_seq', 1, false);


--
-- Data for Name: spree_tax_rates; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_tax_rates (id, amount, zone_id, tax_category_id, included_in_price, created_at, updated_at, name, show_rate_in_label, deleted_at) FROM stdin;
\.


--
-- Name: spree_tax_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_tax_rates_id_seq', 1, false);


--
-- Data for Name: spree_taxonomies; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_taxonomies (id, name, created_at, updated_at, "position") FROM stdin;
2	Algorithms	2014-05-29 20:32:31.359779	2014-07-22 18:57:17.543716	1
5	Software	2014-05-29 20:35:27.459829	2014-07-22 18:58:32.937701	3
1	Mobile	2014-05-29 20:27:36.172667	2014-11-14 15:47:24.356632	0
\.


--
-- Name: spree_taxonomies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_taxonomies_id_seq', 1, false);


--
-- Data for Name: spree_taxons; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_taxons (id, parent_id, "position", name, permalink, taxonomy_id, lft, rgt, icon_file_name, icon_content_type, icon_file_size, icon_updated_at, description, created_at, updated_at, meta_title, meta_description, meta_keywords, depth) FROM stdin;
4	\N	0	Algorithms	algorithms	2	7	12	\N	\N	\N	\N	\N	2014-05-29 20:32:31.405546	2014-07-22 18:57:17.543064	\N	\N	\N	0
7	\N	0	Software	software	5	13	18	\N	\N	\N	\N	\N	2014-05-29 20:35:27.462377	2014-07-22 18:58:32.93706	\N	\N	\N	0
8	7	0	Web Applications	software/web-applications	5	14	15	\N	\N	\N	\N	\N	2014-05-29 20:36:06.079417	2014-07-22 18:58:32.93706	\N	\N	\N	1
9	7	0	Desktop Applications	software/desktop-applications	5	16	17	\N	\N	\N	\N	\N	2014-05-29 20:36:14.403793	2014-07-22 18:56:57.571252	\N	\N	\N	1
10	4	0	Excel formulas	algorithms/excel-formulas	2	8	9	\N	\N	\N	\N	\N	2014-05-29 20:36:36.093881	2014-05-29 20:36:36.100128	\N	\N	\N	1
11	4	0	Matlab	algorithms/matlab	2	10	11	\N	\N	\N	\N	\N	2014-05-29 20:36:43.913916	2014-05-29 20:36:43.920497	\N	\N	\N	1
3	1	0	Android	mobile/android	1	4	5	\N	\N	\N	\N	\N	2014-05-29 20:27:59.898081	2014-11-13 15:55:05.0621	\N	\N	\N	1
1	\N	0	Mobile	mobile	1	1	6	\N	\N	\N	\N	\N	2014-05-29 20:27:36.245427	2014-11-14 15:47:24.354768	\N	\N	\N	0
2	1	0	iOS	mobile/ios	1	2	3	\N	\N	\N	\N	\N	2014-05-29 20:27:53.475676	2014-11-14 15:47:24.354768	\N	\N	\N	1
\.


--
-- Name: spree_taxons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_taxons_id_seq', 1, false);


--
-- Data for Name: spree_tokenized_permissions; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_tokenized_permissions (id, permissable_id, permissable_type, token, created_at, updated_at) FROM stdin;
1	1	Spree::Order	f77a88fe9f4f20c6	2014-07-18 17:47:03.417799	2014-07-18 17:47:03.417799
\.


--
-- Name: spree_tokenized_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_tokenized_permissions_id_seq', 1, false);


--
-- Data for Name: spree_trackers; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_trackers (id, environment, analytics_id, active, created_at, updated_at) FROM stdin;
\.


--
-- Name: spree_trackers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_trackers_id_seq', 1, false);


--
-- Data for Name: spree_users; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_users (id, encrypted_password, password_salt, email, remember_token, persistence_token, reset_password_token, perishable_token, sign_in_count, failed_attempts, last_request_at, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, login, ship_address_id, bill_address_id, authentication_token, unlock_token, locked_at, reset_password_sent_at, created_at, updated_at, spree_api_key, remember_created_at) FROM stdin;
3	b418cb406a86554a96804b339155d219cb3e438cd880e1a150c5d4332ceb617104f675dc965d421fe5de184dbbb9ee9e6073e9ffea3b7b6954c9f31376b3e7f2	CkyMKKnAqo2TEJYz5dXZ	rockwell.66@osu.edu	UCpn6Ja7kyXpXGyjcxPJ	\N	\N	\N	3	0	\N	2014-10-14 19:10:37.914914	2014-07-22 16:56:21.489361	164.107.103.115	164.107.102.74	rockwell.66@osu.edu	\N	\N	\N	\N	\N	\N	2014-07-18 14:22:48.917991	2014-10-14 19:10:37.916874	\N	2014-07-18 17:35:08.938739
4	8abeeb753f05e49104091a1a1fea6d0263198f6f811e8c21409d46c00937311860fb57a5e6efa167d5ecb8bf72fada50a0e81a20dc766e8f4de4b6144b9abfcc	iH8kmU9NtckCeTEaf6pY	hardman.37@osu.edu	gmJgZa2s_yAxQrx6DTKE	\N	\N	\N	2	0	\N	2014-07-22 14:34:01.213273	2014-07-18 17:44:44.085199	128.146.144.125	128.146.144.125	hardman.37@osu.edu	\N	\N	\N	\N	\N	\N	2014-07-18 17:41:47.296271	2014-07-22 14:34:01.213947	\N	2014-07-22 14:34:01.206278
1	cc2d87e0968c56d534d38bdfc8c1fe0f979cc0f73245e0142f74089a86b812a7817be1b3a50fafd306d2525d2e6bb78265191022a6507f6253a9ee01458aad72	G7k3ssV7QgZrsyS9NqfH	paul.pwc@gmail.com	\N	\N	\N	\N	1	0	\N	2014-11-14 15:43:30.068664	2014-11-14 15:43:30.068664	172.16.128.2	172.16.128.2	paul.pwc@gmail.com	12	11	\N	\N	\N	\N	2014-11-14 15:43:30.006851	2014-11-14 15:44:05.491446	\N	\N
2	245c1708fe1e70bd7d905c6fd1447f1f91b2ea883befbdda2ca7bcbd862faa54b6bd096fde2a647d6db0466a4cc63300ea586197da437d87f095b213e092d9aa	6E4uSSmzo5itPGdapooP	cook.424@osu.edu	\N	\N	ec8fa9e35a423086edd0d404f1874b52f0cae61d5509480147205a45f13e3159	\N	10	0	\N	2014-11-19 15:20:18.578238	2014-11-18 14:33:24.474621	172.16.128.2	172.16.128.2	cook.424@osu.edu	4	3	\N	\N	\N	2014-06-03 12:32:02.943486	2014-05-29 20:21:30.419845	2014-11-19 15:20:18.579029	6c3094d1ec86293255e7116a3d00fb5ee5f1af4f8eaa96b2	\N
\.


--
-- Name: spree_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_users_id_seq', 1, true);


--
-- Data for Name: spree_variants; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_variants (id, sku, weight, height, width, depth, deleted_at, is_master, product_id, cost_price, "position", cost_currency, track_inventory, tax_category_id, updated_at) FROM stdin;
1	OSUBRAND1	0.00	\N	\N	\N	2014-07-22 14:39:22.373426	t	1	\N	1	USD	t	\N	2014-07-22 14:39:22.373426
2	FAMOUSSK	0.00	\N	\N	\N	2014-07-22 14:35:47.416776	t	2	\N	1	USD	t	\N	2014-07-22 14:35:47.416776
3	NACLSDK1	0.00	\N	\N	\N	2014-07-22 14:38:46.007733	t	3	\N	1	USD	t	\N	2014-07-22 14:38:46.007733
4	CODIQAIDE1	0.00	\N	\N	\N	2014-07-22 14:35:39.518386	t	4	\N	1	USD	t	\N	2014-07-22 14:35:39.518386
5	FRAMER1	0.00	\N	\N	\N	2014-07-22 14:36:01.42463	t	5	\N	1	USD	t	\N	2014-07-22 14:36:01.42463
6	OSUMOB1	0.00	\N	\N	\N	\N	t	6	\N	1	USD	t	\N	2014-07-22 17:03:11.539558
7	OBUS1	0.00	\N	\N	\N	\N	t	7	\N	1	USD	t	\N	2014-07-18 17:50:39.880226
8	POCUG1	0.00	\N	\N	\N	\N	t	8	\N	1	USD	t	\N	2014-07-21 14:33:46.64751
9	IP1	0.00	\N	\N	\N	\N	t	9	\N	1	USD	t	\N	2014-07-21 14:38:40.428087
10	P4C1	0.00	\N	\N	\N	\N	t	10	\N	1	USD	t	\N	2014-07-21 14:41:55.430644
11	RUOK1	0.00	\N	\N	\N	\N	t	11	\N	1	USD	t	\N	2014-07-21 14:54:56.353247
12	CU1	0.00	\N	\N	\N	\N	t	12	\N	1	USD	t	\N	2014-07-21 15:03:13.60077
13	MT1	0.00	\N	\N	\N	\N	t	13	\N	1	USD	t	\N	2014-07-21 15:32:29.995796
14	HOL1	0.00	\N	\N	\N	\N	t	14	\N	1	USD	t	\N	2014-07-21 16:49:14.327192
15	GB1	0.00	\N	\N	\N	\N	t	15	\N	1	USD	t	\N	2014-07-21 16:50:42.417232
16	EYW1	0.00	\N	\N	\N	\N	t	16	\N	1	USD	t	\N	2014-07-21 16:52:02.460759
17	CFK1	0.00	\N	\N	\N	\N	t	17	\N	1	USD	t	\N	2014-07-22 17:45:33.819209
18	GIR1	0.00	\N	\N	\N	\N	t	18	\N	1	USD	t	\N	2014-07-22 17:54:36.106807
19	WRIS1	0.00	\N	\N	\N	\N	t	19	\N	1	USD	t	\N	2014-07-22 18:52:08.433891
20	RPDA1	0.00	\N	\N	\N	\N	t	20	\N	1	USD	t	\N	2014-07-22 18:49:24.216899
21	OPCW1	0.00	\N	\N	\N	\N	t	21	\N	1	USD	t	\N	2014-07-22 18:22:59.716559
22	IHCVM	0.00	\N	\N	\N	\N	t	22	\N	1	USD	t	\N	2014-07-22 18:02:47.042535
23	LGT1	0.00	\N	\N	\N	\N	t	23	\N	1	USD	t	\N	2014-07-22 18:04:28.117347
24	XIM1	0.00	\N	\N	\N	\N	t	24	\N	1	USD	t	\N	2014-07-22 18:52:57.351548
25	TH1	0.00	\N	\N	\N	\N	t	25	\N	1	USD	t	\N	2014-07-22 18:51:33.441055
26	NAC1	0.00	\N	\N	\N	\N	t	26	\N	1	USD	t	\N	2014-07-22 18:08:22.450478
27	XLT1	0.00	\N	\N	\N	2014-07-22 18:52:26.881948	t	27	\N	1	USD	t	\N	2014-07-22 18:52:26.881948
28	STS1	0.00	\N	\N	\N	\N	t	28	\N	1	USD	t	\N	2014-07-22 18:50:11.265545
29	FLSCS1	0.00	\N	\N	\N	\N	t	29	\N	1	USD	t	\N	2014-07-22 17:49:29.476564
30	SAFP1	0.00	\N	\N	\N	2014-07-22 14:46:33.800916	t	30	\N	1	USD	t	\N	2014-07-22 14:46:33.800916
\.


--
-- Name: spree_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_variants_id_seq', 1, false);


--
-- Data for Name: spree_zone_members; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_zone_members (id, zoneable_id, zoneable_type, zone_id, created_at, updated_at) FROM stdin;
1	72	Spree::Country	1	2014-05-29 20:20:16.111534	2014-05-29 20:20:16.111534
2	10	Spree::Country	1	2014-05-29 20:20:16.121868	2014-05-29 20:20:16.121868
3	76	Spree::Country	1	2014-05-29 20:20:16.127938	2014-05-29 20:20:16.127938
4	94	Spree::Country	1	2014-05-29 20:20:16.13434	2014-05-29 20:20:16.13434
5	155	Spree::Country	1	2014-05-29 20:20:16.142934	2014-05-29 20:20:16.142934
6	13	Spree::Country	1	2014-05-29 20:20:16.149028	2014-05-29 20:20:16.149028
7	164	Spree::Country	1	2014-05-29 20:20:16.155043	2014-05-29 20:20:16.155043
8	217	Spree::Country	1	2014-05-29 20:20:16.161093	2014-05-29 20:20:16.161093
9	167	Spree::Country	1	2014-05-29 20:20:16.167227	2014-05-29 20:20:16.167227
10	20	Spree::Country	1	2014-05-29 20:20:16.173073	2014-05-29 20:20:16.173073
11	111	Spree::Country	1	2014-05-29 20:20:16.178958	2014-05-29 20:20:16.178958
12	175	Spree::Country	1	2014-05-29 20:20:16.184872	2014-05-29 20:20:16.184872
13	24	Spree::Country	1	2014-05-29 20:20:16.19076	2014-05-29 20:20:16.19076
14	29	Spree::Country	1	2014-05-29 20:20:16.197783	2014-05-29 20:20:16.197783
15	98	Spree::Country	1	2014-05-29 20:20:16.203727	2014-05-29 20:20:16.203727
16	180	Spree::Country	1	2014-05-29 20:20:16.209693	2014-05-29 20:20:16.209693
17	182	Spree::Country	1	2014-05-29 20:20:16.215639	2014-05-29 20:20:16.215639
18	44	Spree::Country	1	2014-05-29 20:20:16.221568	2014-05-29 20:20:16.221568
19	206	Spree::Country	1	2014-05-29 20:20:16.227627	2014-05-29 20:20:16.227627
20	46	Spree::Country	1	2014-05-29 20:20:16.233585	2014-05-29 20:20:16.233585
21	211	Spree::Country	1	2014-05-29 20:20:16.239852	2014-05-29 20:20:16.239852
22	135	Spree::Country	1	2014-05-29 20:20:16.245964	2014-05-29 20:20:16.245964
23	56	Spree::Country	1	2014-05-29 20:20:16.252095	2014-05-29 20:20:16.252095
24	207	Spree::Country	1	2014-05-29 20:20:16.25831	2014-05-29 20:20:16.25831
25	210	Spree::Country	1	2014-05-29 20:20:16.264346	2014-05-29 20:20:16.264346
26	49	Spree::Country	2	2014-05-29 20:20:16.271151	2014-05-29 20:20:16.271151
27	204	Spree::Country	2	2014-05-29 20:20:16.277292	2014-05-29 20:20:16.277292
\.


--
-- Name: spree_zone_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_zone_members_id_seq', 1, false);


--
-- Data for Name: spree_zones; Type: TABLE DATA; Schema: public; Owner: vagrant
--

COPY spree_zones (id, name, description, default_tax, zone_members_count, created_at, updated_at) FROM stdin;
1	EU_VAT	Countries that make up the EU VAT zone.	f	25	2014-05-29 20:20:16.061139	2014-05-29 20:20:16.061139
2	North America	USA + Canada	f	2	2014-05-29 20:20:16.08463	2014-05-29 20:20:16.08463
\.


--
-- Name: spree_zones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vagrant
--

SELECT pg_catalog.setval('spree_zones_id_seq', 1, false);


--
-- Name: licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: spree_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_addresses
    ADD CONSTRAINT spree_addresses_pkey PRIMARY KEY (id);


--
-- Name: spree_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_adjustments
    ADD CONSTRAINT spree_adjustments_pkey PRIMARY KEY (id);


--
-- Name: spree_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_assets
    ADD CONSTRAINT spree_assets_pkey PRIMARY KEY (id);


--
-- Name: spree_calculators_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_calculators
    ADD CONSTRAINT spree_calculators_pkey PRIMARY KEY (id);


--
-- Name: spree_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_configurations
    ADD CONSTRAINT spree_configurations_pkey PRIMARY KEY (id);


--
-- Name: spree_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_countries
    ADD CONSTRAINT spree_countries_pkey PRIMARY KEY (id);


--
-- Name: spree_credit_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_credit_cards
    ADD CONSTRAINT spree_credit_cards_pkey PRIMARY KEY (id);


--
-- Name: spree_digital_links_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_digital_links
    ADD CONSTRAINT spree_digital_links_pkey PRIMARY KEY (id);


--
-- Name: spree_digitals_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_digitals
    ADD CONSTRAINT spree_digitals_pkey PRIMARY KEY (id);


--
-- Name: spree_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_gateways
    ADD CONSTRAINT spree_gateways_pkey PRIMARY KEY (id);


--
-- Name: spree_inventory_units_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_inventory_units
    ADD CONSTRAINT spree_inventory_units_pkey PRIMARY KEY (id);


--
-- Name: spree_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_line_items
    ADD CONSTRAINT spree_line_items_pkey PRIMARY KEY (id);


--
-- Name: spree_log_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_log_entries
    ADD CONSTRAINT spree_log_entries_pkey PRIMARY KEY (id);


--
-- Name: spree_option_types_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_option_types
    ADD CONSTRAINT spree_option_types_pkey PRIMARY KEY (id);


--
-- Name: spree_option_values_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_option_values
    ADD CONSTRAINT spree_option_values_pkey PRIMARY KEY (id);


--
-- Name: spree_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_orders
    ADD CONSTRAINT spree_orders_pkey PRIMARY KEY (id);


--
-- Name: spree_payment_capture_events_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_payment_capture_events
    ADD CONSTRAINT spree_payment_capture_events_pkey PRIMARY KEY (id);


--
-- Name: spree_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_payment_methods
    ADD CONSTRAINT spree_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: spree_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_payments
    ADD CONSTRAINT spree_payments_pkey PRIMARY KEY (id);


--
-- Name: spree_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_preferences
    ADD CONSTRAINT spree_preferences_pkey PRIMARY KEY (id);


--
-- Name: spree_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_prices
    ADD CONSTRAINT spree_prices_pkey PRIMARY KEY (id);


--
-- Name: spree_product_option_types_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_product_option_types
    ADD CONSTRAINT spree_product_option_types_pkey PRIMARY KEY (id);


--
-- Name: spree_product_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_product_properties
    ADD CONSTRAINT spree_product_properties_pkey PRIMARY KEY (id);


--
-- Name: spree_products_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_products
    ADD CONSTRAINT spree_products_pkey PRIMARY KEY (id);


--
-- Name: spree_products_taxons_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_products_taxons
    ADD CONSTRAINT spree_products_taxons_pkey PRIMARY KEY (id);


--
-- Name: spree_promotion_action_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_promotion_action_line_items
    ADD CONSTRAINT spree_promotion_action_line_items_pkey PRIMARY KEY (id);


--
-- Name: spree_promotion_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_promotion_actions
    ADD CONSTRAINT spree_promotion_actions_pkey PRIMARY KEY (id);


--
-- Name: spree_promotion_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_promotion_rules
    ADD CONSTRAINT spree_promotion_rules_pkey PRIMARY KEY (id);


--
-- Name: spree_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_promotions
    ADD CONSTRAINT spree_promotions_pkey PRIMARY KEY (id);


--
-- Name: spree_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_properties
    ADD CONSTRAINT spree_properties_pkey PRIMARY KEY (id);


--
-- Name: spree_prototypes_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_prototypes
    ADD CONSTRAINT spree_prototypes_pkey PRIMARY KEY (id);


--
-- Name: spree_return_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_return_authorizations
    ADD CONSTRAINT spree_return_authorizations_pkey PRIMARY KEY (id);


--
-- Name: spree_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_roles
    ADD CONSTRAINT spree_roles_pkey PRIMARY KEY (id);


--
-- Name: spree_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_shipments
    ADD CONSTRAINT spree_shipments_pkey PRIMARY KEY (id);


--
-- Name: spree_shipping_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_shipping_categories
    ADD CONSTRAINT spree_shipping_categories_pkey PRIMARY KEY (id);


--
-- Name: spree_shipping_method_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_shipping_method_categories
    ADD CONSTRAINT spree_shipping_method_categories_pkey PRIMARY KEY (id);


--
-- Name: spree_shipping_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_shipping_methods
    ADD CONSTRAINT spree_shipping_methods_pkey PRIMARY KEY (id);


--
-- Name: spree_shipping_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_shipping_rates
    ADD CONSTRAINT spree_shipping_rates_pkey PRIMARY KEY (id);


--
-- Name: spree_skrill_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_skrill_transactions
    ADD CONSTRAINT spree_skrill_transactions_pkey PRIMARY KEY (id);


--
-- Name: spree_state_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_state_changes
    ADD CONSTRAINT spree_state_changes_pkey PRIMARY KEY (id);


--
-- Name: spree_states_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_states
    ADD CONSTRAINT spree_states_pkey PRIMARY KEY (id);


--
-- Name: spree_stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_stock_items
    ADD CONSTRAINT spree_stock_items_pkey PRIMARY KEY (id);


--
-- Name: spree_stock_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_stock_locations
    ADD CONSTRAINT spree_stock_locations_pkey PRIMARY KEY (id);


--
-- Name: spree_stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_stock_movements
    ADD CONSTRAINT spree_stock_movements_pkey PRIMARY KEY (id);


--
-- Name: spree_stock_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_stock_transfers
    ADD CONSTRAINT spree_stock_transfers_pkey PRIMARY KEY (id);


--
-- Name: spree_stores_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_stores
    ADD CONSTRAINT spree_stores_pkey PRIMARY KEY (id);


--
-- Name: spree_tax_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_tax_categories
    ADD CONSTRAINT spree_tax_categories_pkey PRIMARY KEY (id);


--
-- Name: spree_tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_tax_rates
    ADD CONSTRAINT spree_tax_rates_pkey PRIMARY KEY (id);


--
-- Name: spree_taxonomies_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_taxonomies
    ADD CONSTRAINT spree_taxonomies_pkey PRIMARY KEY (id);


--
-- Name: spree_taxons_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_taxons
    ADD CONSTRAINT spree_taxons_pkey PRIMARY KEY (id);


--
-- Name: spree_tokenized_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_tokenized_permissions
    ADD CONSTRAINT spree_tokenized_permissions_pkey PRIMARY KEY (id);


--
-- Name: spree_trackers_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_trackers
    ADD CONSTRAINT spree_trackers_pkey PRIMARY KEY (id);


--
-- Name: spree_users_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_users
    ADD CONSTRAINT spree_users_pkey PRIMARY KEY (id);


--
-- Name: spree_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_variants
    ADD CONSTRAINT spree_variants_pkey PRIMARY KEY (id);


--
-- Name: spree_zone_members_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_zone_members
    ADD CONSTRAINT spree_zone_members_pkey PRIMARY KEY (id);


--
-- Name: spree_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: vagrant; Tablespace: 
--

ALTER TABLE ONLY spree_zones
    ADD CONSTRAINT spree_zones_pkey PRIMARY KEY (id);


--
-- Name: email_idx_unique; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX email_idx_unique ON spree_users USING btree (email);


--
-- Name: index_addresses_on_firstname; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_addresses_on_firstname ON spree_addresses USING btree (firstname);


--
-- Name: index_addresses_on_lastname; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_addresses_on_lastname ON spree_addresses USING btree (lastname);


--
-- Name: index_adjustments_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_adjustments_on_order_id ON spree_adjustments USING btree (adjustable_id);


--
-- Name: index_assets_on_viewable_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_assets_on_viewable_id ON spree_assets USING btree (viewable_id);


--
-- Name: index_assets_on_viewable_type_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_assets_on_viewable_type_and_type ON spree_assets USING btree (viewable_type, type);


--
-- Name: index_inventory_units_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_inventory_units_on_order_id ON spree_inventory_units USING btree (order_id);


--
-- Name: index_inventory_units_on_shipment_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_inventory_units_on_shipment_id ON spree_inventory_units USING btree (shipment_id);


--
-- Name: index_inventory_units_on_variant_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_inventory_units_on_variant_id ON spree_inventory_units USING btree (variant_id);


--
-- Name: index_option_values_variants_on_variant_id_and_option_value_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_option_values_variants_on_variant_id_and_option_value_id ON spree_option_values_variants USING btree (variant_id, option_value_id);


--
-- Name: index_product_properties_on_product_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_product_properties_on_product_id ON spree_product_properties USING btree (product_id);


--
-- Name: index_products_promotion_rules_on_product_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_products_promotion_rules_on_product_id ON spree_products_promotion_rules USING btree (product_id);


--
-- Name: index_products_promotion_rules_on_promotion_rule_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_products_promotion_rules_on_promotion_rule_id ON spree_products_promotion_rules USING btree (promotion_rule_id);


--
-- Name: index_promotion_rules_on_product_group_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_promotion_rules_on_product_group_id ON spree_promotion_rules USING btree (product_group_id);


--
-- Name: index_promotion_rules_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_promotion_rules_on_user_id ON spree_promotion_rules USING btree (user_id);


--
-- Name: index_promotion_rules_users_on_promotion_rule_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_promotion_rules_users_on_promotion_rule_id ON spree_promotion_rules_users USING btree (promotion_rule_id);


--
-- Name: index_promotion_rules_users_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_promotion_rules_users_on_user_id ON spree_promotion_rules_users USING btree (user_id);


--
-- Name: index_shipments_on_number; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_shipments_on_number ON spree_shipments USING btree (number);


--
-- Name: index_spree_addresses_on_country_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_addresses_on_country_id ON spree_addresses USING btree (country_id);


--
-- Name: index_spree_addresses_on_state_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_addresses_on_state_id ON spree_addresses USING btree (state_id);


--
-- Name: index_spree_adjustments_on_adjustable_id_and_adjustable_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_adjustments_on_adjustable_id_and_adjustable_type ON spree_adjustments USING btree (adjustable_id, adjustable_type);


--
-- Name: index_spree_adjustments_on_eligible; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_adjustments_on_eligible ON spree_adjustments USING btree (eligible);


--
-- Name: index_spree_adjustments_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_adjustments_on_order_id ON spree_adjustments USING btree (order_id);


--
-- Name: index_spree_adjustments_on_source_id_and_source_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_adjustments_on_source_id_and_source_type ON spree_adjustments USING btree (source_id, source_type);


--
-- Name: index_spree_calculators_on_calculable_id_and_calculable_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_calculators_on_calculable_id_and_calculable_type ON spree_calculators USING btree (calculable_id, calculable_type);


--
-- Name: index_spree_calculators_on_id_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_calculators_on_id_and_type ON spree_calculators USING btree (id, type);


--
-- Name: index_spree_configurations_on_name_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_configurations_on_name_and_type ON spree_configurations USING btree (name, type);


--
-- Name: index_spree_credit_cards_on_address_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_credit_cards_on_address_id ON spree_credit_cards USING btree (address_id);


--
-- Name: index_spree_credit_cards_on_payment_method_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_credit_cards_on_payment_method_id ON spree_credit_cards USING btree (payment_method_id);


--
-- Name: index_spree_credit_cards_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_credit_cards_on_user_id ON spree_credit_cards USING btree (user_id);


--
-- Name: index_spree_digital_links_on_digital_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_digital_links_on_digital_id ON spree_digital_links USING btree (digital_id);


--
-- Name: index_spree_digital_links_on_line_item_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_digital_links_on_line_item_id ON spree_digital_links USING btree (line_item_id);


--
-- Name: index_spree_digital_links_on_secret; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_digital_links_on_secret ON spree_digital_links USING btree (secret);


--
-- Name: index_spree_digitals_on_variant_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_digitals_on_variant_id ON spree_digitals USING btree (variant_id);


--
-- Name: index_spree_gateways_on_active; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_gateways_on_active ON spree_gateways USING btree (active);


--
-- Name: index_spree_gateways_on_test_mode; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_gateways_on_test_mode ON spree_gateways USING btree (test_mode);


--
-- Name: index_spree_inventory_units_on_line_item_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_inventory_units_on_line_item_id ON spree_inventory_units USING btree (line_item_id);


--
-- Name: index_spree_inventory_units_on_return_authorization_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_inventory_units_on_return_authorization_id ON spree_inventory_units USING btree (return_authorization_id);


--
-- Name: index_spree_line_items_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_line_items_on_order_id ON spree_line_items USING btree (order_id);


--
-- Name: index_spree_line_items_on_tax_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_line_items_on_tax_category_id ON spree_line_items USING btree (tax_category_id);


--
-- Name: index_spree_line_items_on_variant_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_line_items_on_variant_id ON spree_line_items USING btree (variant_id);


--
-- Name: index_spree_log_entries_on_source_id_and_source_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_log_entries_on_source_id_and_source_type ON spree_log_entries USING btree (source_id, source_type);


--
-- Name: index_spree_option_types_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_option_types_on_position ON spree_option_types USING btree ("position");


--
-- Name: index_spree_option_values_on_option_type_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_option_values_on_option_type_id ON spree_option_values USING btree (option_type_id);


--
-- Name: index_spree_option_values_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_option_values_on_position ON spree_option_values USING btree ("position");


--
-- Name: index_spree_option_values_variants_on_variant_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_option_values_variants_on_variant_id ON spree_option_values_variants USING btree (variant_id);


--
-- Name: index_spree_orders_on_approver_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_approver_id ON spree_orders USING btree (approver_id);


--
-- Name: index_spree_orders_on_bill_address_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_bill_address_id ON spree_orders USING btree (bill_address_id);


--
-- Name: index_spree_orders_on_completed_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_completed_at ON spree_orders USING btree (completed_at);


--
-- Name: index_spree_orders_on_confirmation_delivered; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_confirmation_delivered ON spree_orders USING btree (confirmation_delivered);


--
-- Name: index_spree_orders_on_considered_risky; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_considered_risky ON spree_orders USING btree (considered_risky);


--
-- Name: index_spree_orders_on_created_by_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_created_by_id ON spree_orders USING btree (created_by_id);


--
-- Name: index_spree_orders_on_number; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_number ON spree_orders USING btree (number);


--
-- Name: index_spree_orders_on_ship_address_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_ship_address_id ON spree_orders USING btree (ship_address_id);


--
-- Name: index_spree_orders_on_shipping_method_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_shipping_method_id ON spree_orders USING btree (shipping_method_id);


--
-- Name: index_spree_orders_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_user_id ON spree_orders USING btree (user_id);


--
-- Name: index_spree_orders_on_user_id_and_created_by_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_on_user_id_and_created_by_id ON spree_orders USING btree (user_id, created_by_id);


--
-- Name: index_spree_orders_promotions_on_order_id_and_promotion_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_orders_promotions_on_order_id_and_promotion_id ON spree_orders_promotions USING btree (order_id, promotion_id);


--
-- Name: index_spree_payment_capture_events_on_payment_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_payment_capture_events_on_payment_id ON spree_payment_capture_events USING btree (payment_id);


--
-- Name: index_spree_payment_methods_on_id_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_payment_methods_on_id_and_type ON spree_payment_methods USING btree (id, type);


--
-- Name: index_spree_payments_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_payments_on_order_id ON spree_payments USING btree (order_id);


--
-- Name: index_spree_payments_on_payment_method_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_payments_on_payment_method_id ON spree_payments USING btree (payment_method_id);


--
-- Name: index_spree_payments_on_source_id_and_source_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_payments_on_source_id_and_source_type ON spree_payments USING btree (source_id, source_type);


--
-- Name: index_spree_preferences_on_key; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX index_spree_preferences_on_key ON spree_preferences USING btree (key);


--
-- Name: index_spree_prices_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_prices_on_deleted_at ON spree_prices USING btree (deleted_at);


--
-- Name: index_spree_prices_on_variant_id_and_currency; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_prices_on_variant_id_and_currency ON spree_prices USING btree (variant_id, currency);


--
-- Name: index_spree_product_option_types_on_option_type_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_product_option_types_on_option_type_id ON spree_product_option_types USING btree (option_type_id);


--
-- Name: index_spree_product_option_types_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_product_option_types_on_position ON spree_product_option_types USING btree ("position");


--
-- Name: index_spree_product_option_types_on_product_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_product_option_types_on_product_id ON spree_product_option_types USING btree (product_id);


--
-- Name: index_spree_product_properties_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_product_properties_on_position ON spree_product_properties USING btree ("position");


--
-- Name: index_spree_product_properties_on_property_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_product_properties_on_property_id ON spree_product_properties USING btree (property_id);


--
-- Name: index_spree_products_on_available_on; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_available_on ON spree_products USING btree (available_on);


--
-- Name: index_spree_products_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_deleted_at ON spree_products USING btree (deleted_at);


--
-- Name: index_spree_products_on_name; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_name ON spree_products USING btree (name);


--
-- Name: index_spree_products_on_shipping_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_shipping_category_id ON spree_products USING btree (shipping_category_id);


--
-- Name: index_spree_products_on_slug; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_slug ON spree_products USING btree (slug);


--
-- Name: index_spree_products_on_tax_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_on_tax_category_id ON spree_products USING btree (tax_category_id);


--
-- Name: index_spree_products_taxons_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_taxons_on_position ON spree_products_taxons USING btree ("position");


--
-- Name: index_spree_products_taxons_on_product_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_taxons_on_product_id ON spree_products_taxons USING btree (product_id);


--
-- Name: index_spree_products_taxons_on_taxon_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_products_taxons_on_taxon_id ON spree_products_taxons USING btree (taxon_id);


--
-- Name: index_spree_promotion_action_line_items_on_promotion_action_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_action_line_items_on_promotion_action_id ON spree_promotion_action_line_items USING btree (promotion_action_id);


--
-- Name: index_spree_promotion_action_line_items_on_variant_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_action_line_items_on_variant_id ON spree_promotion_action_line_items USING btree (variant_id);


--
-- Name: index_spree_promotion_actions_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_actions_on_deleted_at ON spree_promotion_actions USING btree (deleted_at);


--
-- Name: index_spree_promotion_actions_on_id_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_actions_on_id_and_type ON spree_promotion_actions USING btree (id, type);


--
-- Name: index_spree_promotion_actions_on_promotion_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_actions_on_promotion_id ON spree_promotion_actions USING btree (promotion_id);


--
-- Name: index_spree_promotion_rules_on_promotion_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotion_rules_on_promotion_id ON spree_promotion_rules USING btree (promotion_id);


--
-- Name: index_spree_promotions_on_advertise; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotions_on_advertise ON spree_promotions USING btree (advertise);


--
-- Name: index_spree_promotions_on_code; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotions_on_code ON spree_promotions USING btree (code);


--
-- Name: index_spree_promotions_on_expires_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotions_on_expires_at ON spree_promotions USING btree (expires_at);


--
-- Name: index_spree_promotions_on_id_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotions_on_id_and_type ON spree_promotions USING btree (id, type);


--
-- Name: index_spree_promotions_on_starts_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_promotions_on_starts_at ON spree_promotions USING btree (starts_at);


--
-- Name: index_spree_return_authorizations_on_number; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_return_authorizations_on_number ON spree_return_authorizations USING btree (number);


--
-- Name: index_spree_return_authorizations_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_return_authorizations_on_order_id ON spree_return_authorizations USING btree (order_id);


--
-- Name: index_spree_return_authorizations_on_stock_location_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_return_authorizations_on_stock_location_id ON spree_return_authorizations USING btree (stock_location_id);


--
-- Name: index_spree_roles_users_on_role_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_roles_users_on_role_id ON spree_roles_users USING btree (role_id);


--
-- Name: index_spree_roles_users_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_roles_users_on_user_id ON spree_roles_users USING btree (user_id);


--
-- Name: index_spree_shipments_on_address_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipments_on_address_id ON spree_shipments USING btree (address_id);


--
-- Name: index_spree_shipments_on_order_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipments_on_order_id ON spree_shipments USING btree (order_id);


--
-- Name: index_spree_shipments_on_stock_location_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipments_on_stock_location_id ON spree_shipments USING btree (stock_location_id);


--
-- Name: index_spree_shipping_method_categories_on_shipping_method_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipping_method_categories_on_shipping_method_id ON spree_shipping_method_categories USING btree (shipping_method_id);


--
-- Name: index_spree_shipping_methods_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipping_methods_on_deleted_at ON spree_shipping_methods USING btree (deleted_at);


--
-- Name: index_spree_shipping_methods_on_tax_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipping_methods_on_tax_category_id ON spree_shipping_methods USING btree (tax_category_id);


--
-- Name: index_spree_shipping_rates_on_selected; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipping_rates_on_selected ON spree_shipping_rates USING btree (selected);


--
-- Name: index_spree_shipping_rates_on_tax_rate_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_shipping_rates_on_tax_rate_id ON spree_shipping_rates USING btree (tax_rate_id);


--
-- Name: index_spree_state_changes_on_stateful_id_and_stateful_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_state_changes_on_stateful_id_and_stateful_type ON spree_state_changes USING btree (stateful_id, stateful_type);


--
-- Name: index_spree_state_changes_on_user_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_state_changes_on_user_id ON spree_state_changes USING btree (user_id);


--
-- Name: index_spree_states_on_country_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_states_on_country_id ON spree_states USING btree (country_id);


--
-- Name: index_spree_stock_items_on_backorderable; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_items_on_backorderable ON spree_stock_items USING btree (backorderable);


--
-- Name: index_spree_stock_items_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_items_on_deleted_at ON spree_stock_items USING btree (deleted_at);


--
-- Name: index_spree_stock_items_on_stock_location_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_items_on_stock_location_id ON spree_stock_items USING btree (stock_location_id);


--
-- Name: index_spree_stock_locations_on_active; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_locations_on_active ON spree_stock_locations USING btree (active);


--
-- Name: index_spree_stock_locations_on_backorderable_default; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_locations_on_backorderable_default ON spree_stock_locations USING btree (backorderable_default);


--
-- Name: index_spree_stock_locations_on_country_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_locations_on_country_id ON spree_stock_locations USING btree (country_id);


--
-- Name: index_spree_stock_locations_on_propagate_all_variants; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_locations_on_propagate_all_variants ON spree_stock_locations USING btree (propagate_all_variants);


--
-- Name: index_spree_stock_locations_on_state_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_locations_on_state_id ON spree_stock_locations USING btree (state_id);


--
-- Name: index_spree_stock_movements_on_stock_item_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_movements_on_stock_item_id ON spree_stock_movements USING btree (stock_item_id);


--
-- Name: index_spree_stock_transfers_on_destination_location_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_transfers_on_destination_location_id ON spree_stock_transfers USING btree (destination_location_id);


--
-- Name: index_spree_stock_transfers_on_number; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_transfers_on_number ON spree_stock_transfers USING btree (number);


--
-- Name: index_spree_stock_transfers_on_source_location_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stock_transfers_on_source_location_id ON spree_stock_transfers USING btree (source_location_id);


--
-- Name: index_spree_stores_on_code; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stores_on_code ON spree_stores USING btree (code);


--
-- Name: index_spree_stores_on_default; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stores_on_default ON spree_stores USING btree ("default");


--
-- Name: index_spree_stores_on_url; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_stores_on_url ON spree_stores USING btree (url);


--
-- Name: index_spree_tax_categories_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_categories_on_deleted_at ON spree_tax_categories USING btree (deleted_at);


--
-- Name: index_spree_tax_categories_on_is_default; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_categories_on_is_default ON spree_tax_categories USING btree (is_default);


--
-- Name: index_spree_tax_rates_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_rates_on_deleted_at ON spree_tax_rates USING btree (deleted_at);


--
-- Name: index_spree_tax_rates_on_included_in_price; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_rates_on_included_in_price ON spree_tax_rates USING btree (included_in_price);


--
-- Name: index_spree_tax_rates_on_show_rate_in_label; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_rates_on_show_rate_in_label ON spree_tax_rates USING btree (show_rate_in_label);


--
-- Name: index_spree_tax_rates_on_tax_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_rates_on_tax_category_id ON spree_tax_rates USING btree (tax_category_id);


--
-- Name: index_spree_tax_rates_on_zone_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_tax_rates_on_zone_id ON spree_tax_rates USING btree (zone_id);


--
-- Name: index_spree_taxonomies_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_taxonomies_on_position ON spree_taxonomies USING btree ("position");


--
-- Name: index_spree_taxons_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_taxons_on_position ON spree_taxons USING btree ("position");


--
-- Name: index_spree_trackers_on_active; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_trackers_on_active ON spree_trackers USING btree (active);


--
-- Name: index_spree_users_on_spree_api_key; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_users_on_spree_api_key ON spree_users USING btree (spree_api_key);


--
-- Name: index_spree_variants_on_deleted_at; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_deleted_at ON spree_variants USING btree (deleted_at);


--
-- Name: index_spree_variants_on_is_master; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_is_master ON spree_variants USING btree (is_master);


--
-- Name: index_spree_variants_on_position; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_position ON spree_variants USING btree ("position");


--
-- Name: index_spree_variants_on_product_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_product_id ON spree_variants USING btree (product_id);


--
-- Name: index_spree_variants_on_sku; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_sku ON spree_variants USING btree (sku);


--
-- Name: index_spree_variants_on_tax_category_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_tax_category_id ON spree_variants USING btree (tax_category_id);


--
-- Name: index_spree_variants_on_track_inventory; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_variants_on_track_inventory ON spree_variants USING btree (track_inventory);


--
-- Name: index_spree_zone_members_on_zone_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_zone_members_on_zone_id ON spree_zone_members USING btree (zone_id);


--
-- Name: index_spree_zone_members_on_zoneable_id_and_zoneable_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_zone_members_on_zoneable_id_and_zoneable_type ON spree_zone_members USING btree (zoneable_id, zoneable_type);


--
-- Name: index_spree_zones_on_default_tax; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_spree_zones_on_default_tax ON spree_zones USING btree (default_tax);


--
-- Name: index_taxons_on_parent_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_taxons_on_parent_id ON spree_taxons USING btree (parent_id);


--
-- Name: index_taxons_on_permalink; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_taxons_on_permalink ON spree_taxons USING btree (permalink);


--
-- Name: index_taxons_on_taxonomy_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_taxons_on_taxonomy_id ON spree_taxons USING btree (taxonomy_id);


--
-- Name: index_tokenized_name_and_type; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX index_tokenized_name_and_type ON spree_tokenized_permissions USING btree (permissable_id, permissable_type);


--
-- Name: permalink_idx_unique; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX permalink_idx_unique ON spree_products USING btree (slug);


--
-- Name: spree_shipping_rates_join_index; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX spree_shipping_rates_join_index ON spree_shipping_rates USING btree (shipment_id, shipping_method_id);


--
-- Name: stock_item_by_loc_and_var_id; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE INDEX stock_item_by_loc_and_var_id ON spree_stock_items USING btree (stock_location_id, variant_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: unique_spree_shipping_method_categories; Type: INDEX; Schema: public; Owner: vagrant; Tablespace: 
--

CREATE UNIQUE INDEX unique_spree_shipping_method_categories ON spree_shipping_method_categories USING btree (shipping_category_id, shipping_method_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

